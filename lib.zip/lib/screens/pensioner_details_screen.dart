import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../config/routes.dart';
import '../providers/kyc_provider.dart';
import '../screens/certificate_webview_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens
// ─────────────────────────────────────────────────────────────────────────────
class _DS {
  static const Color headerBg = Color(0xFF7BBDE4);
  static const Color headerText = Colors.white;
  static const Color pageBg = Color(0xFFF2F5FA);
  static const Color cardBg = Colors.white;
  static const Color cardBorder = Color(0xFF93C4E8);
  static const double cardRadius = 12.0;
  static const double cardBorderWidth = 1.5;
  static const Color labelColor = Color(0xFF8A9BB0);
  static const double labelFontSize = 13.0;
  static const Color valueColor = Color(0xFF1A1A1A);
  static const double valueFontSize = 15.5;
  static const Color divider = Color(0xFFDDE4EE);
  static const Color buttonBg = Color(0xFF3A9BDC);
  static const Color buttonText = Colors.white;
  static const double buttonRadius = 16.0;
  static const double rowPaddingV = 12.0;
  static const double cardPaddingH = 16.0;
  static const double cardPaddingV = 4.0;

  // Validation error color
  static const Color errorColor = Color(0xFFD32F2F);
  static const Color errorBg = Color(0xFFFFF0F0);
  static const Color errorBorder = Color(0xFFFFCDD2);

  // ── Normalised status constants (all lowercase) ──────────────────────────
  // IMPORTANT: Always compare against these — never against the raw API string
  // because status is normalised with .toLowerCase() before comparison.
  static const String statusApproved = 'application approved';
  static const String statusPending = 'verification in progress';
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: build the certificate URL
// ─────────────────────────────────────────────────────────────────────────────
String _buildCertUrl(String? financialYear, int? certificateId) {
  if (financialYear == null || certificateId == null) return '';
  final yearPart = financialYear.replaceAll('-', '_');
  return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────
class PensionerDetailsScreen extends StatefulWidget {
  const PensionerDetailsScreen({super.key});

  @override
  State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
}

class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
  final _aadhaarController = TextEditingController();
  final _addressController = TextEditingController();
  String? _selectedGender;

  // ── Validation error state ─────────────────────────────────────────────────
  String? _aadhaarError;
  String? _addressError;
  String? _genderError;

  @override
  void initState() {
    super.initState();
    final provider = context.read<KycProvider>();
    _aadhaarController.text = provider.aadhaarNumber ?? '';
    _addressController.text = provider.address ?? '';
    _selectedGender = provider.gender;
  }

  @override
  void dispose() {
    _aadhaarController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  // ── Normalised status helper ───────────────────────────────────────────────
  // Always use this instead of calling .toLowerCase() ad-hoc to ensure
  // every comparison in the file uses the same normalised value.
  String? get _normalisedStatus =>
      context.read<KycProvider>().verificationStatus?.toLowerCase().trim();

  // ── Is status pending? ─────────────────────────────────────────────────────
  bool get _isPending => _normalisedStatus == _DS.statusPending;

  // ── Exit app (works on Android + iOS) ─────────────────────────────────────
  void _exitApp() {
    if (Platform.isAndroid) {
      SystemNavigator.pop();
    } else {
      exit(0);
    }
  }

  // ── Form validation ────────────────────────────────────────────────────────
  bool _validateForm() {
    final aadhaar = _aadhaarController.text.trim();
    final address = _addressController.text.trim();

    String? aadhaarErr;
    String? addressErr;
    String? genderErr;

    if (aadhaar.isEmpty) {
      aadhaarErr = 'Aadhaar number is required. / आधार क्रमांक आवश्यक आहे.';
    } else if (!RegExp(r'^\d{12}$').hasMatch(aadhaar)) {
      if (aadhaar.length < 12) {
        aadhaarErr =
            'Aadhaar must be 12 digits — too short. / आधार 12 अंकी असणे आवश्यक आहे — खूप कमी.';
      } else if (aadhaar.length > 12) {
        aadhaarErr =
            'Aadhaar must be 12 digits — too long. / आधार 12 अंकी असणे आवश्यक आहे — खूप जास्त.';
      } else {
        aadhaarErr =
            'Aadhaar must contain digits only. / आधार फक्त अंक असणे आवश्यक आहे.';
      }
    }

    if (address.isEmpty) {
      addressErr = 'Address is required. / पत्ता आवश्यक आहे.';
    }

    if (_selectedGender == null || _selectedGender!.isEmpty) {
      genderErr = 'Please select a gender. / कृपया लिंग निवडा.';
    }

    setState(() {
      _aadhaarError = aadhaarErr;
      _addressError = addressErr;
      _genderError = genderErr;
    });

    return aadhaarErr == null && addressErr == null && genderErr == null;
  }

  // ── Show exit-confirmation dialog when back is pressed (PENDING only) ──────
  void _showExitDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext ctx) {
        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: const Row(
            children: [
              Icon(Icons.info_outline, color: Colors.orange, size: 28),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Verification Status',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          content: const Text(
            'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                _exitApp();
              },
              child: const Text(
                'OK',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        );
      },
    );
  }

  // ── "Verification In Progress" button tap — info only, no exit ────────────
  void _showPendingInfoDialog() {
    showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: const Row(
            children: [
              Icon(Icons.info_outline, color: Colors.orange, size: 28),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Verification Status',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          content: const Text(
            'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text(
                'OK',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        );
      },
    );
  }

  // ── Single unified back handler ────────────────────────────────────────────
  void _handleBack() {
    if (_isPending) {
      _showExitDialog();
    } else {
      Navigator.of(context).pop();
    }
  }

  // ── "Generate Life Certificate" — validates before proceeding ─────────────
  Future<void> _proceed() async {
    if (!_validateForm()) return;

    final provider = context.read<KycProvider>();
    final success = await provider.savePensionerDetails(
      newAadhaar: _aadhaarController.text.trim(),
      newAddress: _addressController.text.trim(),
      newGender: _selectedGender,
    );
    if (!success || !mounted) return;
    if (provider.shouldSkipAadhaarVerification) {
      Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
    } else {
      Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
    }
  }

  // ── "View Certificate" ─────────────────────────────────────────────────────
  void _viewCertificate() {
    final provider = context.read<KycProvider>();
    final url = _buildCertUrl(provider.financialYear, provider.certificateId);
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Certificate details not available. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CertificateWebViewScreen(url: url)),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Build
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Consumer<KycProvider>(
      builder: (_, provider, __) {
        return WillPopScope(
          onWillPop: () async {
            _handleBack();
            return false;
          },
          child: Scaffold(
            backgroundColor: _DS.pageBg,
            appBar: AppBar(
              backgroundColor: _DS.headerBg,
              elevation: 0,
              centerTitle: true,
              automaticallyImplyLeading: false,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: _DS.headerText),
                onPressed: _handleBack,
              ),
              title: const Text(
                'Pensioner Details [Step-2]',
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            body: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (provider.isKycCompleted || provider.isReturningPensioner)
                    _buildReadOnlyCard(provider)
                  else
                    _buildEditableForm(provider),
                  const SizedBox(height: 14),
                  _buildVerificationStatusCard(provider),
                  const SizedBox(height: 18),
                  _buildCtaButton(provider),
                  if (provider.error != null) ...[
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        provider.error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ── Read-only details card ────────────────────────────────────────────────
  Widget _buildReadOnlyCard(KycProvider provider) {
    return _DetailsCard(
      children: [
        _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
        _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
        _DetailRow(
          label: 'Aadhar Number(आधार नंबर):',
          value: provider.aadhaarNumber ?? '—',
          showDivider: true,
        ),
        _DetailRow(
          label: 'Pension Type(पेन्शन प्रकार):',
          value: provider.pensionType ?? '—',
          showDivider: true,
        ),
        _DetailRow(
          label: 'Address(पत्ता):',
          value: provider.address ?? '—',
          isLast: true,
        ),
      ],
    );
  }

  // ── Editable form card ────────────────────────────────────────────────────
  Widget _buildEditableForm(KycProvider provider) {
    return _DetailsCard(
      children: [
        _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
        _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),

        // ── Aadhaar field ──────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Aadhar Number(आधार नंबर):',
                style: TextStyle(
                  fontSize: _DS.labelFontSize,
                  color: _DS.labelColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              TextField(
                controller: _aadhaarController,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(12),
                ],
                maxLength: 12,
                decoration: InputDecoration(
                  counterText: '${_aadhaarController.text.length} / 12',
                  errorText: _aadhaarError,
                  errorStyle: const TextStyle(
                    color: _DS.errorColor,
                    fontSize: 12,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                      color: _aadhaarError != null
                          ? _DS.errorColor
                          : const Color(0xFFDDE4EE),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                      color:
                          _aadhaarError != null ? _DS.errorColor : _DS.buttonBg,
                      width: 1.5,
                    ),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: _DS.errorColor),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide:
                        const BorderSide(color: _DS.errorColor, width: 1.5),
                  ),
                  filled: _aadhaarError != null,
                  fillColor:
                      _aadhaarError != null ? _DS.errorBg : Colors.transparent,
                  hint: const Text('Enter 12-digit Aadhaar'),
                ),
                onChanged: (_) {
                  if (_aadhaarError != null) {
                    setState(() => _aadhaarError = null);
                  }
                },
              ),
            ],
          ),
        ),

        // ── Gender field ───────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Gender(लिंग):',
                style: TextStyle(
                  fontSize: _DS.labelFontSize,
                  color: _DS.labelColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              DropdownButtonFormField<String>(
                value: _selectedGender,
                decoration: InputDecoration(
                  errorText: _genderError,
                  errorStyle: const TextStyle(
                    color: _DS.errorColor,
                    fontSize: 12,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                      color: _genderError != null
                          ? _DS.errorColor
                          : const Color(0xFFDDE4EE),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                      color:
                          _genderError != null ? _DS.errorColor : _DS.buttonBg,
                      width: 1.5,
                    ),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: _DS.errorColor),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide:
                        const BorderSide(color: _DS.errorColor, width: 1.5),
                  ),
                  filled: _genderError != null,
                  fillColor:
                      _genderError != null ? _DS.errorBg : Colors.transparent,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                ),
                hint: const Text('Select Gender / लिंग निवडा'),
                items: const [
                  DropdownMenuItem(value: 'Male', child: Text('Male')),
                  DropdownMenuItem(value: 'Female', child: Text('Female')),
                  DropdownMenuItem(value: 'Other', child: Text('Other')),
                ],
                onChanged: (val) {
                  setState(() {
                    _selectedGender = val;
                    _genderError = null;
                  });
                },
              ),
            ],
          ),
        ),

        // ── Address field ──────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Address(पत्ता):',
                style: TextStyle(
                  fontSize: _DS.labelFontSize,
                  color: _DS.labelColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              TextField(
                controller: _addressController,
                maxLines: 3,
                decoration: InputDecoration(
                  errorText: _addressError,
                  errorStyle: const TextStyle(
                    color: _DS.errorColor,
                    fontSize: 12,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                      color: _addressError != null
                          ? _DS.errorColor
                          : const Color(0xFFDDE4EE),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(
                      color:
                          _addressError != null ? _DS.errorColor : _DS.buttonBg,
                      width: 1.5,
                    ),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: _DS.errorColor),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide:
                        const BorderSide(color: _DS.errorColor, width: 1.5),
                  ),
                  filled: _addressError != null,
                  fillColor:
                      _addressError != null ? _DS.errorBg : Colors.transparent,
                  hint: const Text('Enter your address'),
                ),
                onChanged: (_) {
                  if (_addressError != null) {
                    setState(() => _addressError = null);
                  }
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── Verification status card ──────────────────────────────────────────────
  Widget _buildVerificationStatusCard(KycProvider provider) {
    final status = provider.verificationStatus;
    final hasStatus = status != null && status.isNotEmpty;

    return Container(
      decoration: BoxDecoration(
        color: _DS.cardBg,
        borderRadius: BorderRadius.circular(_DS.cardRadius),
        border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
      ),
      padding: const EdgeInsets.symmetric(
          horizontal: _DS.cardPaddingH, vertical: _DS.cardPaddingV),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Text(
              'Verification Status(पडताळणी ची सद्यस्थिती):',
              style: TextStyle(
                  fontSize: _DS.labelFontSize,
                  color: _DS.labelColor,
                  fontWeight: FontWeight.w500),
            ),
          ),
          if (hasStatus) ...[
            _StatusBadge(status: status!),
            const SizedBox(height: 8),
          ] else
            const SizedBox(height: 28),
          const Divider(color: _DS.divider, thickness: 1, height: 1),
          const SizedBox(height: 4),
        ],
      ),
    );
  }

  // ── CTA button ────────────────────────────────────────────────────────────
  // FIX: status is normalised to lowercase BEFORE comparison so the
  // mixed-case API strings ("Application Approved", "Verification In Progress")
  // are matched correctly against the lowercase constants in _DS.
  Widget _buildCtaButton(KycProvider provider) {
    // Normalise once — all comparisons below use this lowercase value.
    final status = provider.verificationStatus?.toLowerCase().trim();

    // ── "Application Approved" → show View Certificate ───────────────────
    if (status == _DS.statusApproved) {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: _viewCertificate,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF28A745),
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(_DS.buttonRadius)),
            elevation: 3,
            shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.workspace_premium, color: Colors.white, size: 18),
                  SizedBox(width: 8),
                  Text('View Certificate',
                      style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700,
                          color: Colors.white)),
                ],
              ),
              SizedBox(height: 3),
              Text('प्रमाणपत्र पहा',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: Colors.white)),
            ],
          ),
        ),
      );
    }

    // ── "Verification In Progress" → show info button ────────────────────
    if (status == _DS.statusPending) {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: _showPendingInfoDialog,
          style: ElevatedButton.styleFrom(
            backgroundColor: _DS.buttonBg,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(_DS.buttonRadius)),
            elevation: 2,
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Verification In Progress',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: _DS.buttonText)),
              SizedBox(height: 3),
              Text('पडताळणी प्रगतीपथावर आहे',
                  style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                      color: _DS.buttonText)),
            ],
          ),
        ),
      );
    }

    // ── Default → Generate Life Certificate ─────────────────────────────
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: provider.isLoading ? null : _proceed,
        style: ElevatedButton.styleFrom(
          backgroundColor: _DS.buttonBg,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(_DS.buttonRadius)),
          elevation: 3,
          shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
        ),
        child: provider.isLoading
            ? const SizedBox(
                height: 22,
                width: 22,
                child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(Colors.white)),
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Generate Your Life Certificate',
                      style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700,
                          color: _DS.buttonText)),
                  const SizedBox(height: 3),
                  const Text('जीवन प्रमाणपत्र तयार करा',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: _DS.buttonText)),
                  const SizedBox(height: 2),
                  Text('(${provider.financialYear ?? '2026-2027'})',
                      style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: _DS.buttonText)),
                ],
              ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _DetailsCard
// ─────────────────────────────────────────────────────────────────────────────
class _DetailsCard extends StatelessWidget {
  final List<Widget> children;
  const _DetailsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _DS.cardBg,
        borderRadius: BorderRadius.circular(_DS.cardRadius),
        border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
      ),
      padding: const EdgeInsets.symmetric(
          horizontal: _DS.cardPaddingH, vertical: _DS.cardPaddingV),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _DetailRow
// ─────────────────────────────────────────────────────────────────────────────
class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final bool showDivider;
  final bool isLast;

  const _DetailRow({
    required this.label,
    required this.value,
    this.showDivider = false,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(
              top: _DS.rowPaddingV, bottom: isLast ? _DS.rowPaddingV : 2),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: _DS.labelFontSize,
                      color: _DS.labelColor,
                      fontWeight: FontWeight.w500)),
              const SizedBox(height: 3),
              Text(value,
                  style: const TextStyle(
                      fontSize: _DS.valueFontSize,
                      color: _DS.valueColor,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
        if (showDivider) const SizedBox(height: 4),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _StatusBadge
// FIX: Compare against lowercase constants (_DS.statusApproved /
// _DS.statusPending) — never against the raw mixed-case API strings.
// ─────────────────────────────────────────────────────────────────────────────
class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    // Normalise once here; all comparisons below use the lowercase value.
    final lower = status.toLowerCase().trim();

    Color bg, border, text;
    IconData icon;
    String label, marathi;

    if (lower == _DS.statusApproved) {
      bg = const Color(0xFFE8F9EE);
      border = const Color(0xFF34A853);
      text = const Color(0xFF1E8740);
      icon = Icons.check_circle_outline;
      label = 'Application Approved';
      marathi = 'अर्ज मंजूर';
    } else if (lower == _DS.statusPending) {
      bg = const Color(0xFFEAF3FB);
      border = _DS.buttonBg;
      text = _DS.buttonBg;
      icon = Icons.hourglass_bottom;
      label = 'Verification In Progress';
      marathi = 'पडताळणी प्रगतीपथावर आहे';
    } else {
      bg = const Color(0xFFF5F5F5);
      border = const Color(0xFFBBBBBB);
      text = const Color(0xFF666666);
      icon = Icons.info_outline;
      label = status;
      marathi = '';
    }

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: border, width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: text, size: 20),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(
                      color: text,
                      fontWeight: FontWeight.w700,
                      fontSize: 13.5)),
              if (marathi.isNotEmpty)
                Text(marathi, style: TextStyle(color: text, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}


// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';

// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';
// import '../screens/certificate_webview_screen.dart';

// // ─────────────────────────────────────────────────────────────────────────────
// // Design tokens
// // ─────────────────────────────────────────────────────────────────────────────
// class _DS {
//   static const Color headerBg = Color(0xFF7BBDE4);
//   static const Color headerText = Colors.white;
//   static const Color pageBg = Color(0xFFF2F5FA);
//   static const Color cardBg = Colors.white;
//   static const Color cardBorder = Color(0xFF93C4E8);
//   static const double cardRadius = 12.0;
//   static const double cardBorderWidth = 1.5;
//   static const Color labelColor = Color(0xFF8A9BB0);
//   static const double labelFontSize = 13.0;
//   static const Color valueColor = Color(0xFF1A1A1A);
//   static const double valueFontSize = 15.5;
//   static const Color divider = Color(0xFFDDE4EE);
//   static const Color buttonBg = Color(0xFF3A9BDC);
//   static const Color buttonText = Colors.white;
//   static const double buttonRadius = 16.0;
//   static const double rowPaddingV = 12.0;
//   static const double cardPaddingH = 16.0;
//   static const double cardPaddingV = 4.0;

//   // Validation error color
//   static const Color errorColor = Color(0xFFD32F2F);
//   static const Color errorBg = Color(0xFFFFF0F0);
//   static const Color errorBorder = Color(0xFFFFCDD2);
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Helper: build the certificate URL
// // ─────────────────────────────────────────────────────────────────────────────
// String _buildCertUrl(String? financialYear, int? certificateId) {
//   if (financialYear == null || certificateId == null) return '';
//   final yearPart = financialYear.replaceAll('-', '_');
//   return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Main Screen
// // ─────────────────────────────────────────────────────────────────────────────
// class PensionerDetailsScreen extends StatefulWidget {
//   const PensionerDetailsScreen({super.key});

//   @override
//   State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
// }

// class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
//   final _aadhaarController = TextEditingController();
//   final _addressController = TextEditingController();
//   String? _selectedGender;

//   // ── Validation error state ─────────────────────────────────────────────────
//   String? _aadhaarError;
//   String? _addressError;
//   String? _genderError;

//   @override
//   void initState() {
//     super.initState();
//     final provider = context.read<KycProvider>();
//     _aadhaarController.text = provider.aadhaarNumber ?? '';
//     _addressController.text = provider.address ?? '';
//     _selectedGender = provider.gender;
//   }

//   @override
//   void dispose() {
//     _aadhaarController.dispose();
//     _addressController.dispose();
//     super.dispose();
//   }

//   // ── Is status pending? ─────────────────────────────────────────────────────
//   bool get _isPending =>
//       context.read<KycProvider>().verificationStatus?.toLowerCase() ==
//       'pending';

//   // ── Exit app (works on Android + iOS) ─────────────────────────────────────
//   void _exitApp() {
//     if (Platform.isAndroid) {
//       SystemNavigator.pop();
//     } else {
//       exit(0);
//     }
//   }

//   // ── Form validation ────────────────────────────────────────────────────────
//   // Returns true if ALL fields are valid, false otherwise.
//   // Also sets individual error strings so the UI can show inline errors.
//   bool _validateForm() {
//     final aadhaar = _aadhaarController.text.trim();
//     final address = _addressController.text.trim();

//     String? aadhaarErr;
//     String? addressErr;
//     String? genderErr;

//     // --- Aadhaar: must be exactly 12 digits (no letters, no spaces) ----------
//     if (aadhaar.isEmpty) {
//       aadhaarErr = 'Aadhaar number is required. / आधार क्रमांक आवश्यक आहे.';
//     } else if (!RegExp(r'^\d{12}$').hasMatch(aadhaar)) {
//       if (aadhaar.length < 12) {
//         aadhaarErr =
//             'Aadhaar must be 12 digits — too short. / आधार 12 अंकी असणे आवश्यक आहे — खूप कमी.';
//       } else if (aadhaar.length > 12) {
//         aadhaarErr =
//             'Aadhaar must be 12 digits — too long. / आधार 12 अंकी असणे आवश्यक आहे — खूप जास्त.';
//       } else {
//         aadhaarErr =
//             'Aadhaar must contain digits only. / आधार फक्त अंक असणे आवश्यक आहे.';
//       }
//     }

//     // --- Address: must not be empty ------------------------------------------
//     if (address.isEmpty) {
//       addressErr = 'Address is required. / पत्ता आवश्यक आहे.';
//     }

//     // --- Gender: must be selected --------------------------------------------
//     if (_selectedGender == null || _selectedGender!.isEmpty) {
//       genderErr = 'Please select a gender. / कृपया लिंग निवडा.';
//     }

//     setState(() {
//       _aadhaarError = aadhaarErr;
//       _addressError = addressErr;
//       _genderError = genderErr;
//     });

//     return aadhaarErr == null && addressErr == null && genderErr == null;
//   }

//   // ── Show exit-confirmation dialog when back is pressed (PENDING only) ──────
//   void _showExitDialog() {
//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(ctx).pop();
//                 _exitApp();
//               },
//               child: const Text(
//                 'OK',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── "Verification In Progress" button tap — info only, no exit ────────────
//   void _showPendingInfoDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(   
//               onPressed: () => Navigator.of(ctx).pop(),
//               child: const Text(
//                 'OK',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── Single unified back handler ────────────────────────────────────────────
//   void _handleBack() {
//     if (_isPending) {
//       _showExitDialog();
//     } else {
//       Navigator.of(context).pop();
//     }
//   }

//   // ── "Generate Life Certificate" — validates before proceeding ─────────────
//   Future<void> _proceed() async {
//     // Run validation first; abort if any field is invalid.
//     if (!_validateForm()) return;

//     final provider = context.read<KycProvider>();
//     final success = await provider.savePensionerDetails(
//       newAadhaar: _aadhaarController.text.trim(),
//       newAddress: _addressController.text.trim(),
//       newGender: _selectedGender,
//     );
//     if (!success || !mounted) return;
//     if (provider.shouldSkipAadhaarVerification) {
//       Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
//     } else {
//       Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
//     }
//   }

//   // ── "View Certificate" ─────────────────────────────────────────────────────
//   void _viewCertificate() {
//     final provider = context.read<KycProvider>();
//     final url = _buildCertUrl(provider.financialYear, provider.certificateId);
//     if (url.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('Certificate details not available. Please try again.'),
//           backgroundColor: Colors.red,
//         ),
//       );
//       return;
//     }
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (_) => CertificateWebViewScreen(url: url)),
//     );
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Build
//   // ─────────────────────────────────────────────────────────────────────────
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<KycProvider>(
//       builder: (_, provider, __) {
//         return WillPopScope(
//           onWillPop: () async {
//             _handleBack();
//             return false;
//           },
//           child: Scaffold(
//             backgroundColor: _DS.pageBg,
//             appBar: AppBar(
//               backgroundColor: _DS.headerBg,
//               elevation: 0,
//               centerTitle: true,
//               automaticallyImplyLeading: false,
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: _DS.headerText),
//                 onPressed: _handleBack,
//               ),
//               title: const Text(
//                 'Pensioner Details [Step-2]',
//                 style: TextStyle(
//                   color: Colors.black87,
//                   fontSize: 18,
//                   fontWeight: FontWeight.w700,
//                 ),
//               ),
//             ),
//             body: SingleChildScrollView(
//               padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 children: [
//                   if (provider.isKycCompleted || provider.isReturningPensioner)
//                     _buildReadOnlyCard(provider)
//                   else
//                     _buildEditableForm(provider),
//                   const SizedBox(height: 14),
//                   _buildVerificationStatusCard(provider),
//                   const SizedBox(height: 18),
//                   _buildCtaButton(provider),
//                   if (provider.error != null) ...[
//                     const SizedBox(height: 14),
//                     Container(
//                       padding: const EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: Colors.red.withValues(alpha: 0.08),
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Text(
//                         provider.error!,
//                         style: const TextStyle(color: Colors.red),
//                         textAlign: TextAlign.center,
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // ── Read-only details card ────────────────────────────────────────────────
//   Widget _buildReadOnlyCard(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         _DetailRow(
//           label: 'Aadhar Number(आधार नंबर):',
//           value: provider.aadhaarNumber ?? '—',
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Pension Type(पेन्शन प्रकार):',
//           value: provider.pensionType ?? '—',
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Address(पत्ता):',
//           value: provider.address ?? '—',
//           isLast: true,
//         ),
//       ],
//     );
//   }

//   // ── Editable form card ────────────────────────────────────────────────────
//   Widget _buildEditableForm(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),

//         // ── Aadhaar field with inline validation ───────────────────────────
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Aadhar Number(आधार नंबर):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _aadhaarController,
//                 keyboardType: TextInputType.number,
//                 // Enforce numeric-only input and hard cap at 12 characters.
//                 inputFormatters: [
//                   FilteringTextInputFormatter.digitsOnly,
//                   LengthLimitingTextInputFormatter(12),
//                 ],
//                 maxLength: 12,
//                 // Live counter so user sees "X / 12" as they type.
//                 decoration: InputDecoration(
//                   counterText: '${_aadhaarController.text.length} / 12',
//                   errorText: _aadhaarError,
//                   errorStyle: const TextStyle(
//                     color: _DS.errorColor,
//                     fontSize: 12,
//                   ),
//                   enabledBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: BorderSide(
//                       color: _aadhaarError != null
//                           ? _DS.errorColor
//                           : const Color(0xFFDDE4EE),
//                     ),
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: BorderSide(
//                       color:
//                           _aadhaarError != null ? _DS.errorColor : _DS.buttonBg,
//                       width: 1.5,
//                     ),
//                   ),
//                   errorBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: const BorderSide(color: _DS.errorColor),
//                   ),
//                   focusedErrorBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide:
//                         const BorderSide(color: _DS.errorColor, width: 1.5),
//                   ),
//                   filled: _aadhaarError != null,
//                   fillColor:
//                       _aadhaarError != null ? _DS.errorBg : Colors.transparent,
//                   hint: const Text('Enter 12-digit Aadhaar '),
//                 ),
//                 // Clear the error as soon as the user starts typing again.
//                 onChanged: (_) {
//                   if (_aadhaarError != null) {
//                     setState(() => _aadhaarError = null);
//                   }
//                 },
//               ),
//             ],
//           ),
//         ),

//         // ── Gender field with inline validation ────────────────────────────
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Gender(लिंग):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               DropdownButtonFormField<String>(
//                 value: _selectedGender,
//                 decoration: InputDecoration(
//                   errorText: _genderError,
//                   errorStyle: const TextStyle(
//                     color: _DS.errorColor,
//                     fontSize: 12,
//                   ),
//                   enabledBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: BorderSide(
//                       color: _genderError != null
//                           ? _DS.errorColor
//                           : const Color(0xFFDDE4EE),
//                     ),
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: BorderSide(
//                       color:
//                           _genderError != null ? _DS.errorColor : _DS.buttonBg,
//                       width: 1.5,
//                     ),
//                   ),
//                   errorBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: const BorderSide(color: _DS.errorColor),
//                   ),
//                   focusedErrorBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide:
//                         const BorderSide(color: _DS.errorColor, width: 1.5),
//                   ),
//                   filled: _genderError != null,
//                   fillColor:
//                       _genderError != null ? _DS.errorBg : Colors.transparent,
//                   contentPadding:
//                       const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
//                 ),
//                 hint: const Text('Select Gender / लिंग निवडा'),
//                 items: const [
//                   DropdownMenuItem(value: 'Male', child: Text('Male')),
//                   DropdownMenuItem(value: 'Female', child: Text('Female')),
//                   DropdownMenuItem(value: 'Other', child: Text('Other')),
//                 ],
//                 onChanged: (val) {
//                   setState(() {
//                     _selectedGender = val;
//                     _genderError = null; // clear error on selection
//                   });
//                 },
//               ),
//             ],
//           ),
//         ),

//         // ── Address field with inline validation ───────────────────────────
//         Padding(
//           padding: const EdgeInsets.only(top: 8, bottom: 4),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Address(पत्ता):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _addressController,
//                 maxLines: 3,
//                 decoration: InputDecoration(
//                   errorText: _addressError,
//                   errorStyle: const TextStyle(
//                     color: _DS.errorColor,
//                     fontSize: 12,
//                   ),
//                   enabledBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: BorderSide(
//                       color: _addressError != null
//                           ? _DS.errorColor
//                           : const Color(0xFFDDE4EE),
//                     ),
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: BorderSide(
//                       color:
//                           _addressError != null ? _DS.errorColor : _DS.buttonBg,
//                       width: 1.5,
//                     ),
//                   ),
//                   errorBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide: const BorderSide(color: _DS.errorColor),
//                   ),
//                   focusedErrorBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                     borderSide:
//                         const BorderSide(color: _DS.errorColor, width: 1.5),
//                   ),
//                   filled: _addressError != null,
//                   fillColor:
//                       _addressError != null ? _DS.errorBg : Colors.transparent,
//                   hint: const Text('Enter your  address'),
//                 ),
//                 onChanged: (_) {
//                   if (_addressError != null) {
//                     setState(() => _addressError = null);
//                   }
//                 },
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // ── Verification status card ──────────────────────────────────────────────
//   Widget _buildVerificationStatusCard(KycProvider provider) {
//     final status = provider.verificationStatus;
//     final hasStatus = status != null && status.isNotEmpty;

//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//           horizontal: _DS.cardPaddingH, vertical: _DS.cardPaddingV),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Padding(
//             padding: EdgeInsets.symmetric(vertical: 10),
//             child: Text(
//               'Verification Status(पडताळणी ची सद्यस्थिती):',
//               style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500),
//             ),
//           ),
//           if (hasStatus) ...[
//             _StatusBadge(status: status!),
//             const SizedBox(height: 8),
//           ] else
//             const SizedBox(height: 28),
//           const Divider(color: _DS.divider, thickness: 1, height: 1),
//           const SizedBox(height: 4),
//         ],
//       ),
//     );
//   }

//   // ── CTA button ────────────────────────────────────────────────────────────
//   Widget _buildCtaButton(KycProvider provider) {
//     final status = provider.verificationStatus?.toLowerCase();

//     if (status == 'approved') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _viewCertificate,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: const Color(0xFF28A745),
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(_DS.buttonRadius)),
//             elevation: 3,
//             shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.workspace_premium, color: Colors.white, size: 18),
//                   SizedBox(width: 8),
//                   Text('View Certificate',
//                       style: TextStyle(
//                           fontSize: 15.5,
//                           fontWeight: FontWeight.w700,
//                           color: Colors.white)),
//                 ],
//               ),
//               SizedBox(height: 3),
//               Text('प्रमाणपत्र पहा',
//                   style: TextStyle(
//                       fontSize: 13,
//                       fontWeight: FontWeight.w500,
//                       color: Colors.white)),
//             ],
//           ),
//         ),
//       );
//     }

//     if (status == 'pending') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _showPendingInfoDialog,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: _DS.buttonBg,
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(_DS.buttonRadius)),
//             elevation: 2,
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text('Verification In Progress',
//                   style: TextStyle(
//                       fontSize: 15,
//                       fontWeight: FontWeight.w700,
//                       color: _DS.buttonText)),
//               SizedBox(height: 3),
//               Text('पडताळणी प्रगतीपथावर आहे',
//                   style: TextStyle(
//                       fontSize: 12.5,
//                       fontWeight: FontWeight.w500,
//                       color: _DS.buttonText)),
//             ],
//           ),
//         ),
//       );
//     }

//     return SizedBox(
//       width: double.infinity,
//       child: ElevatedButton(
//         onPressed: provider.isLoading ? null : _proceed,
//         style: ElevatedButton.styleFrom(
//           backgroundColor: _DS.buttonBg,
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(_DS.buttonRadius)),
//           elevation: 3,
//           shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
//         ),
//         child: provider.isLoading
//             ? const SizedBox(
//                 height: 22,
//                 width: 22,
//                 child: CircularProgressIndicator(
//                     strokeWidth: 2.5,
//                     valueColor: AlwaysStoppedAnimation(Colors.white)),
//               )
//             : Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text('Generate Your Life Certificate',
//                       style: TextStyle(
//                           fontSize: 15.5,
//                           fontWeight: FontWeight.w700,
//                           color: _DS.buttonText)),
//                   const SizedBox(height: 3),
//                   const Text('जीवन प्रमाणपत्र तयार करा',
//                       style: TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w500,
//                           color: _DS.buttonText)),
//                   const SizedBox(height: 2),
//                   Text('(${provider.financialYear ?? '2026-2027'})',
//                       style: const TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w500,
//                           color: _DS.buttonText)),
//                 ],
//               ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailsCard
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailsCard extends StatelessWidget {
//   final List<Widget> children;
//   const _DetailsCard({required this.children});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//           horizontal: _DS.cardPaddingH, vertical: _DS.cardPaddingV),
//       child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start, children: children),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailRow
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailRow extends StatelessWidget {
//   final String label;
//   final String value;
//   final bool showDivider;
//   final bool isLast;

//   const _DetailRow({
//     required this.label,
//     required this.value,
//     this.showDivider = false,
//     this.isLast = false,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Padding(
//           padding: EdgeInsets.only(
//               top: _DS.rowPaddingV, bottom: isLast ? _DS.rowPaddingV : 2),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(label,
//                   style: const TextStyle(
//                       fontSize: _DS.labelFontSize,
//                       color: _DS.labelColor,
//                       fontWeight: FontWeight.w500)),
//               const SizedBox(height: 3),
//               Text(value,
//                   style: const TextStyle(
//                       fontSize: _DS.valueFontSize,
//                       color: _DS.valueColor,
//                       fontWeight: FontWeight.w700)),
//             ],
//           ),
//         ),
//         if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
//         if (showDivider) const SizedBox(height: 4),
//       ],
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _StatusBadge
// // ─────────────────────────────────────────────────────────────────────────────
// class _StatusBadge extends StatelessWidget {
//   final String status;
//   const _StatusBadge({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     final lower = status.toLowerCase();
//     Color bg, border, text;
//     IconData icon;
//     String label, marathi;

//     if (lower == 'approved') {
//       bg = const Color(0xFFE8F9EE);
//       border = const Color(0xFF34A853);
//       text = const Color(0xFF1E8740);
//       icon = Icons.check_circle_outline;
//       label = 'Approved';
//       marathi = 'मंजूर';
//     } else if (lower == 'pending') {
//       bg = const Color(0xFFEAF3FB);
//       border = _DS.buttonBg;
//       text = _DS.buttonBg;
//       icon = Icons.hourglass_bottom;
//       label = 'Verification In Progress';
//       marathi = 'पडताळणी प्रगतीपथावर आहे';
//     } else {
//       bg = const Color(0xFFF5F5F5);
//       border = const Color(0xFFBBBBBB);
//       text = const Color(0xFF666666);
//       icon = Icons.info_outline;
//       label = status;
//       marathi = '';
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
//       decoration: BoxDecoration(
//         color: bg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: border, width: 1.5),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(icon, color: text, size: 20),
//           const SizedBox(width: 8),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(label,
//                   style: TextStyle(
//                       color: text,
//                       fontWeight: FontWeight.w700,
//                       fontSize: 13.5)),
//               if (marathi.isNotEmpty)
//                 Text(marathi, style: TextStyle(color: text, fontSize: 11)),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:provider/provider.dart';

// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';
// import '../screens/certificate_webview_screen.dart';

// // ─────────────────────────────────────────────────────────────────────────────
// // Design tokens
// // ─────────────────────────────────────────────────────────────────────────────
// class _DS {
//   static const Color headerBg = Color(0xFF7BBDE4);
//   static const Color headerText = Colors.white;
//   static const Color pageBg = Color(0xFFF2F5FA);
//   static const Color cardBg = Colors.white;
//   static const Color cardBorder = Color(0xFF93C4E8);
//   static const double cardRadius = 12.0;
//   static const double cardBorderWidth = 1.5;
//   static const Color labelColor = Color(0xFF8A9BB0);
//   static const double labelFontSize = 13.0;
//   static const Color valueColor = Color(0xFF1A1A1A);
//   static const double valueFontSize = 15.5;
//   static const Color divider = Color(0xFFDDE4EE);
//   static const Color buttonBg = Color(0xFF3A9BDC);
//   static const Color buttonText = Colors.white;
//   static const double buttonRadius = 16.0;
//   static const double rowPaddingV = 12.0;
//   static const double cardPaddingH = 16.0;
//   static const double cardPaddingV = 4.0;
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Helper: build the certificate URL
// // ─────────────────────────────────────────────────────────────────────────────
// String _buildCertUrl(String? financialYear, int? certificateId) {
//   if (financialYear == null || certificateId == null) return '';
//   final yearPart = financialYear.replaceAll('-', '_');
//   return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Main Screen
// // ─────────────────────────────────────────────────────────────────────────────
// class PensionerDetailsScreen extends StatefulWidget {
//   const PensionerDetailsScreen({super.key});

//   @override
//   State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
// }

// class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
//   final _aadhaarController = TextEditingController();
//   final _addressController = TextEditingController();
//   String? _selectedGender;

//   @override
//   void initState() {
//     super.initState();
//     final provider = context.read<KycProvider>();
//     _aadhaarController.text = provider.aadhaarNumber ?? '';
//     _addressController.text = provider.address ?? '';
//     _selectedGender = provider.gender;
//   }

//   @override
//   void dispose() {
//     _aadhaarController.dispose();
//     _addressController.dispose();
//     super.dispose();
//   }

//   // ── Is status pending? ─────────────────────────────────────────────────────
//   bool get _isPending =>
//       context.read<KycProvider>().verificationStatus?.toLowerCase() ==
//       'pending';

//   // ── Exit app (works on Android + iOS) ─────────────────────────────────────
//   void _exitApp() {
//     if (Platform.isAndroid) {
//       SystemNavigator.pop();
//     } else {
//       exit(0);
//     }
//   }

//   // ── Show exit-confirmation dialog when back is pressed (PENDING only) ──────
//   // Tapping OK closes the entire app.
//   void _showExitDialog() {
//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(ctx).pop(); // close dialog
//                 _exitApp(); // then exit the app
//               },
//               child: const Text(
//                 'OK',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── "Verification In Progress" button tap — info only, no exit ────────────
//   void _showPendingInfoDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(ctx).pop(), // just dismiss
//               child: const Text(
//                 'OK',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── Single unified back handler ────────────────────────────────────────────
//   // Called by BOTH the AppBar arrow AND the system back gesture.
//   void _handleBack() {
//     if (_isPending) {
//       _showExitDialog();
//     } else {
//       Navigator.of(context).pop();
//     }
//   }

//   // ── "Generate Life Certificate" normal flow ────────────────────────────────
//   Future<void> _proceed() async {
//     final provider = context.read<KycProvider>();
//     final success = await provider.savePensionerDetails(
//       newAadhaar: _aadhaarController.text.trim(),
//       newAddress: _addressController.text.trim(),
//       newGender: _selectedGender,
//     );
//     if (!success || !mounted) return;
//     if (provider.shouldSkipAadhaarVerification) {
//       Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
//     } else {
//       Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
//     }
//   }

//   // ── "View Certificate" ─────────────────────────────────────────────────────
//   void _viewCertificate() {
//     final provider = context.read<KycProvider>();
//     final url = _buildCertUrl(provider.financialYear, provider.certificateId);
//     if (url.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('Certificate details not available. Please try again.'),
//           backgroundColor: Colors.red,
//         ),
//       );
//       return;
//     }
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (_) => CertificateWebViewScreen(url: url)),
//     );
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Build
//   // ─────────────────────────────────────────────────────────────────────────
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<KycProvider>(
//       builder: (_, provider, __) {
//         // ── Universal back-intercept widget ───────────────────────────────
//         // • PopScope  exists in Flutter 3.12+
//         // • WillPopScope is available in all older versions
//         // We try PopScope first; if the class doesn't exist at compile time
//         // the file simply won't compile, so we pick ONE based on your SDK.
//         //
//         // ✅ SAFE FOR ALL VERSIONS: use WillPopScope — it still compiles on
//         //    3.22+ (just shows a deprecation warning, which is harmless).
//         //    If you are on 3.22+ and want to silence the warning, swap
//         //    WillPopScope for PopScope as shown in the comment below.
//         return WillPopScope(
//           // Called by the Android hardware/gesture back.
//           onWillPop: () async {
//             _handleBack();
//             return false; // we always handle navigation ourselves
//           },
//           child: Scaffold(
//             backgroundColor: _DS.pageBg,
//             appBar: AppBar(
//               backgroundColor: _DS.headerBg,
//               elevation: 0,
//               centerTitle: true,
//               // ✅ Disable Flutter's auto back-button so ours is the only one.
//               automaticallyImplyLeading: false,
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: _DS.headerText),
//                 onPressed: _handleBack, // same handler as WillPopScope
//               ),
//               // title: const Text(
//               //   'Pensioner Details [Step-2]',
//               //   style: TextStyle(
//               //     color: _DS.headerText,
//               //     fontSize: 18,
//               //     fontWeight: FontWeight.w700,
//               //   ),
//               // ),
//               title: const Text(
//                 'Pensioner Details [Step-2]',
//                 style: TextStyle(
//                   color: Colors.black87, // ← changed from _DS.headerText
//                   fontSize: 18,
//                   fontWeight: FontWeight.w700,
//                 ),
//               ),
//             ),
//             body: SingleChildScrollView(
//               padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 children: [
//                   if (provider.isKycCompleted || provider.isReturningPensioner)
//                     _buildReadOnlyCard(provider)
//                   else
//                     _buildEditableForm(provider),
//                   const SizedBox(height: 14),
//                   _buildVerificationStatusCard(provider),
//                   const SizedBox(height: 18),
//                   _buildCtaButton(provider),
//                   if (provider.error != null) ...[
//                     const SizedBox(height: 14),
//                     Container(
//                       padding: const EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: Colors.red.withValues(alpha: 0.08),
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Text(
//                         provider.error!,
//                         style: const TextStyle(color: Colors.red),
//                         textAlign: TextAlign.center,
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//           ),
//         );

//         // ── Flutter 3.22+ ONLY — swap WillPopScope above for this: ──────
//         // return PopScope(
//         //   canPop: false,
//         //   onPopInvokedWithResult: (didPop, _) {
//         //     if (!didPop) _handleBack();
//         //   },
//         //   child: Scaffold( ... ),
//         // );
//       },
//     );
//   }

//   // ── Read-only details card ────────────────────────────────────────────────
//   Widget _buildReadOnlyCard(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         // _DetailRow(
//         //   label: 'Aadhar Number(आधार नंबर):',
//         //   value: maskAadhaar(provider.aadhaarNumber),
//         //   showDivider: true,
//         // ),
//         _DetailRow(
//           label: 'Aadhar Number(आधार नंबर):',
//           value: provider.aadhaarNumber ?? '—',
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Pension Type(पेन्शन प्रकार):',
//           value: provider.pensionType ?? '—',
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Address(पत्ता):',
//           value: provider.address ?? '—',
//           isLast: true,
//         ),
//       ],
//     );
//   }

//   // ── Editable form card ────────────────────────────────────────────────────
//   Widget _buildEditableForm(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text('Aadhar Number(आधार नंबर):',
//                   style: TextStyle(
//                       fontSize: _DS.labelFontSize,
//                       color: _DS.labelColor,
//                       fontWeight: FontWeight.w500)),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _aadhaarController,
//                 keyboardType: TextInputType.number,
//                 maxLength: 12,
//                 decoration: const InputDecoration(counterText: ''),
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text('Gender:',
//                   style: TextStyle(
//                       fontSize: _DS.labelFontSize,
//                       color: _DS.labelColor,
//                       fontWeight: FontWeight.w500)),
//               const SizedBox(height: 4),
//               DropdownButtonFormField<String>(
//                 value: _selectedGender,
//                 decoration: const InputDecoration(),
//                 items: const [
//                   DropdownMenuItem(value: 'Male', child: Text('Male')),
//                   DropdownMenuItem(value: 'Female', child: Text('Female')),
//                   DropdownMenuItem(value: 'Other', child: Text('Other')),
//                 ],
//                 onChanged: (val) => setState(() => _selectedGender = val),
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsets.only(top: 8, bottom: 4),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text('Address(पत्ता):',
//                   style: TextStyle(
//                       fontSize: _DS.labelFontSize,
//                       color: _DS.labelColor,
//                       fontWeight: FontWeight.w500)),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _addressController,
//                 maxLines: 3,
//                 decoration: const InputDecoration(),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // ── Verification status card ──────────────────────────────────────────────
//   Widget _buildVerificationStatusCard(KycProvider provider) {
//     final status = provider.verificationStatus;
//     final hasStatus = status != null && status.isNotEmpty;

//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//           horizontal: _DS.cardPaddingH, vertical: _DS.cardPaddingV),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Padding(
//             padding: EdgeInsets.symmetric(vertical: 10),
//             child: Text(
//               'Verification Status(पडताळणी ची सद्यस्थिती):',
//               style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500),
//             ),
//           ),
//           if (hasStatus) ...[
//             _StatusBadge(status: status!),
//             const SizedBox(height: 8),
//           ] else
//             const SizedBox(height: 28),
//           const Divider(color: _DS.divider, thickness: 1, height: 1),
//           const SizedBox(height: 4),
//         ],
//       ),
//     );
//   }

//   // ── CTA button ────────────────────────────────────────────────────────────
//   Widget _buildCtaButton(KycProvider provider) {
//     final status = provider.verificationStatus?.toLowerCase();

//     if (status == 'approved') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _viewCertificate,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: const Color(0xFF28A745),
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(_DS.buttonRadius)),
//             elevation: 3,
//             shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.workspace_premium, color: Colors.white, size: 18),
//                   SizedBox(width: 8),
//                   Text('View Certificate',
//                       style: TextStyle(
//                           fontSize: 15.5,
//                           fontWeight: FontWeight.w700,
//                           color: Colors.white)),
//                 ],
//               ),
//               SizedBox(height: 3),
//               Text('प्रमाणपत्र पहा',
//                   style: TextStyle(
//                       fontSize: 13,
//                       fontWeight: FontWeight.w500,
//                       color: Colors.white)),
//             ],
//           ),
//         ),
//       );
//     }

//     if (status == 'pending') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _showPendingInfoDialog,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: _DS.buttonBg,
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(_DS.buttonRadius)),
//             elevation: 2,
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text('Verification In Progress',
//                   style: TextStyle(
//                       fontSize: 15,
//                       fontWeight: FontWeight.w700,
//                       color: _DS.buttonText)),
//               SizedBox(height: 3),
//               Text('पडताळणी प्रगतीपथावर आहे',
//                   style: TextStyle(
//                       fontSize: 12.5,
//                       fontWeight: FontWeight.w500,
//                       color: _DS.buttonText)),
//             ],
//           ),
//         ),
//       );
//     }

//     return SizedBox(
//       width: double.infinity,
//       child: ElevatedButton(
//         onPressed: provider.isLoading ? null : _proceed,
//         style: ElevatedButton.styleFrom(
//           backgroundColor: _DS.buttonBg,
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(_DS.buttonRadius)),
//           elevation: 3,
//           shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
//         ),
//         child: provider.isLoading
//             ? const SizedBox(
//                 height: 22,
//                 width: 22,
//                 child: CircularProgressIndicator(
//                     strokeWidth: 2.5,
//                     valueColor: AlwaysStoppedAnimation(Colors.white)),
//               )
//             : Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text('Generate Your Life Certificate',
//                       style: TextStyle(
//                           fontSize: 15.5,
//                           fontWeight: FontWeight.w700,
//                           color: _DS.buttonText)),
//                   const SizedBox(height: 3),
//                   const Text('जीवन प्रमाणपत्र तयार करा',
//                       style: TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w500,
//                           color: _DS.buttonText)),
//                   const SizedBox(height: 2),
//                   Text('(${provider.financialYear ?? '2026-2027'})',
//                       style: const TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w500,
//                           color: _DS.buttonText)),
//                 ],
//               ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailsCard
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailsCard extends StatelessWidget {
//   final List<Widget> children;
//   const _DetailsCard({required this.children});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//           horizontal: _DS.cardPaddingH, vertical: _DS.cardPaddingV),
//       child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start, children: children),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailRow
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailRow extends StatelessWidget {
//   final String label;
//   final String value;
//   final bool showDivider;
//   final bool isLast;

//   const _DetailRow({
//     required this.label,
//     required this.value,
//     this.showDivider = false,
//     this.isLast = false,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Padding(
//           padding: EdgeInsets.only(
//               top: _DS.rowPaddingV, bottom: isLast ? _DS.rowPaddingV : 2),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(label,
//                   style: const TextStyle(
//                       fontSize: _DS.labelFontSize,
//                       color: _DS.labelColor,
//                       fontWeight: FontWeight.w500)),
//               const SizedBox(height: 3),
//               Text(value,
//                   style: const TextStyle(
//                       fontSize: _DS.valueFontSize,
//                       color: _DS.valueColor,
//                       fontWeight: FontWeight.w700)),
//             ],
//           ),
//         ),
//         if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
//         if (showDivider) const SizedBox(height: 4),
//       ],
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _StatusBadge
// // ─────────────────────────────────────────────────────────────────────────────
// class _StatusBadge extends StatelessWidget {
//   final String status;
//   const _StatusBadge({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     final lower = status.toLowerCase();
//     Color bg, border, text;
//     IconData icon;
//     String label, marathi;

//     if (lower == 'approved') {
//       bg = const Color(0xFFE8F9EE);
//       border = const Color(0xFF34A853);
//       text = const Color(0xFF1E8740);
//       icon = Icons.check_circle_outline;
//       label = 'Approved';
//       marathi = 'मंजूर';
//     } else if (lower == 'pending') {
//       bg = const Color(0xFFEAF3FB);
//       border = _DS.buttonBg;
//       text = _DS.buttonBg;
//       icon = Icons.hourglass_bottom;
//       label = 'Verification In Progress';
//       marathi = 'पडताळणी प्रगतीपथावर आहे';
//     } else {
//       bg = const Color(0xFFF5F5F5);
//       border = const Color(0xFFBBBBBB);
//       text = const Color(0xFF666666);
//       icon = Icons.info_outline;
//       label = status;
//       marathi = '';
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
//       decoration: BoxDecoration(
//         color: bg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: border, width: 1.5),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(icon, color: text, size: 20),
//           const SizedBox(width: 8),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(label,
//                   style: TextStyle(
//                       color: text,
//                       fontWeight: FontWeight.w700,
//                       fontSize: 13.5)),
//               if (marathi.isNotEmpty)
//                 Text(marathi, style: TextStyle(color: text, fontSize: 11)),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';
// import '../screens/certificate_webview_screen.dart';
// import '../utils/helpers.dart';

// // ─────────────────────────────────────────────────────────────────────────────
// // Design tokens
// // ─────────────────────────────────────────────────────────────────────────────
// class _DS {
//   static const Color headerBg = Color(0xFF7BBDE4);
//   static const Color headerText = Colors.white;
//   static const Color pageBg = Color(0xFFF2F5FA);
//   static const Color cardBg = Colors.white;
//   static const Color cardBorder = Color(0xFF93C4E8);
//   static const double cardRadius = 12.0;
//   static const double cardBorderWidth = 1.5;
//   static const Color labelColor = Color(0xFF8A9BB0);
//   static const double labelFontSize = 13.0;
//   static const Color valueColor = Color(0xFF1A1A1A);
//   static const double valueFontSize = 15.5;
//   static const Color divider = Color(0xFFDDE4EE);
//   static const Color buttonBg = Color(0xFF3A9BDC);
//   static const Color buttonText = Colors.white;
//   static const double buttonRadius = 16.0;
//   static const double rowPaddingV = 12.0;
//   static const double cardPaddingH = 16.0;
//   static const double cardPaddingV = 4.0;
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Helper: build the certificate URL
// // ─────────────────────────────────────────────────────────────────────────────
// String _buildCertUrl(String? financialYear, int? certificateId) {
//   if (financialYear == null || certificateId == null) return '';
//   final yearPart = financialYear.replaceAll('-', '_');
//   return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Main Screen
// // ─────────────────────────────────────────────────────────────────────────────
// class PensionerDetailsScreen extends StatefulWidget {
//   const PensionerDetailsScreen({super.key});

//   @override
//   State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
// }

// class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
//   final _aadhaarController = TextEditingController();
//   final _addressController = TextEditingController();
//   String? _selectedGender;

//   @override
//   void initState() {
//     super.initState();
//     final provider = context.read<KycProvider>();
//     _aadhaarController.text = provider.aadhaarNumber ?? '';
//     _addressController.text = provider.address ?? '';
//     _selectedGender = provider.gender;
//   }

//   @override
//   void dispose() {
//     _aadhaarController.dispose();
//     _addressController.dispose();
//     super.dispose();
//   }

//   // ── Helper: is status pending? ─────────────────────────────────────────────
//   bool get _isPending {
//     final provider = context.read<KycProvider>();
//     return provider.verificationStatus?.toLowerCase() == 'pending';
//   }

//   // ── "Generate Life Certificate" normal flow ────────────────────────────────
//   Future<void> _proceed() async {
//     final provider = context.read<KycProvider>();
//     final success = await provider.savePensionerDetails(
//       newAadhaar: _aadhaarController.text.trim(),
//       newAddress: _addressController.text.trim(),
//       newGender: _selectedGender,
//     );
//     if (!success || !mounted) return;
//     if (provider.shouldSkipAadhaarVerification) {
//       Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
//     } else {
//       Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
//     }
//   }

//   // ── "View Certificate" ─────────────────────────────────────────────────────
//   void _viewCertificate() {
//     final provider = context.read<KycProvider>();
//     final url = _buildCertUrl(provider.financialYear, provider.certificateId);

//     if (url.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('Certificate details not available. Please try again.'),
//           backgroundColor: Colors.red,
//         ),
//       );
//       return;
//     }

//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (_) => CertificateWebViewScreen(url: url),
//       ),
//     );
//   }

//   // ── "Verification In Progress" info dialog (button tap) ───────────────────
//   void _showPendingInfoDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(ctx).pop(),
//               child: const Text('OK',
//                   style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── Back-navigation handler (shared by AppBar arrow + PopScope) ───────────
//   //
//   // KEY FIX:
//   //   • We capture the Navigator reference BEFORE showing the dialog so that
//   //     the context is never stale when we call popUntil inside the dialog.
//   //   • Uses the screen's own BuildContext (not the dialog's ctx) for
//   //     Navigator.of(context) so it always resolves to the right navigator.
//   void _handleBack() {
//     if (!_isPending) {
//       // Normal status — just pop the current screen.
//       Navigator.of(context).pop();
//       return;
//     }

//     // Capture the navigator before async gap.
//     final navigator = Navigator.of(context);

//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(ctx).pop(); // close dialog
//                 // ✅ KEY: use the captured navigator to avoid stale context.
//                 navigator.popUntil((route) => route.isFirst);
//               },
//               child: const Text('OK',
//                   style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Build
//   // ─────────────────────────────────────────────────────────────────────────
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<KycProvider>(
//       builder: (_, provider, __) {
//         return PopScope(
//           // ✅ canPop = false when pending so the system back gesture is
//           //    intercepted; true otherwise so normal back works.
//           canPop: !_isPending,
//           onPopInvokedWithResult: (didPop, _) {
//             // didPop == true  → system already popped (non-pending); nothing to do.
//             // didPop == false → we blocked it (pending); show dialog.
//             if (!didPop) {
//               _handleBack();
//             }
//           },
//           child: Scaffold(
//             backgroundColor: _DS.pageBg,
//             appBar: AppBar(
//               backgroundColor: _DS.headerBg,
//               elevation: 0,
//               centerTitle: true,
//               automaticallyImplyLeading: false, // we draw our own back button
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: _DS.headerText),
//                 onPressed: _handleBack, // ✅ single unified handler
//               ),
//               title: const Text(
//                 'Pensioner Details [Step-2]',
//                 style: TextStyle(
//                   color: _DS.headerText,
//                   fontSize: 18,
//                   fontWeight: FontWeight.w700,
//                 ),
//               ),
//             ),
//             body: SingleChildScrollView(
//               padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 children: [
//                   // ── Details card ────────────────────────────────────────
//                   if (provider.isKycCompleted || provider.isReturningPensioner)
//                     _buildReadOnlyCard(provider)
//                   else
//                     _buildEditableForm(provider),

//                   const SizedBox(height: 14),

//                   // ── Verification Status card ────────────────────────────
//                   _buildVerificationStatusCard(provider),

//                   const SizedBox(height: 18),

//                   // ── CTA Button ──────────────────────────────────────────
//                   _buildCtaButton(provider),

//                   // ── Error ───────────────────────────────────────────────
//                   if (provider.error != null) ...[
//                     const SizedBox(height: 14),
//                     Container(
//                       padding: const EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: Colors.red.withValues(alpha: 0.08),
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Text(
//                         provider.error!,
//                         style: const TextStyle(color: Colors.red),
//                         textAlign: TextAlign.center,
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // ── Read-only details card ────────────────────────────────────────────────
//   Widget _buildReadOnlyCard(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         _DetailRow(
//           label: 'Aadhar Number(आधार नंबर):',
//           value: maskAadhaar(provider.aadhaarNumber),
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Pension Type(पेन्शन प्रकार):',
//           value: provider.pensionType ?? '—',
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Address(पत्ता):',
//           value: provider.address ?? '—',
//           isLast: true,
//         ),
//       ],
//     );
//   }

//   // ── Editable form card ────────────────────────────────────────────────────
//   Widget _buildEditableForm(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Aadhar Number(आधार नंबर):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _aadhaarController,
//                 keyboardType: TextInputType.number,
//                 maxLength: 12,
//                 decoration: const InputDecoration(counterText: ''),
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Gender:',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               DropdownButtonFormField<String>(
//                 value: _selectedGender,
//                 decoration: const InputDecoration(),
//                 items: const [
//                   DropdownMenuItem(value: 'Male', child: Text('Male')),
//                   DropdownMenuItem(value: 'Female', child: Text('Female')),
//                   DropdownMenuItem(value: 'Other', child: Text('Other')),
//                 ],
//                 onChanged: (val) => setState(() => _selectedGender = val),
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsets.only(top: 8, bottom: 4),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Address(पत्ता):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _addressController,
//                 maxLines: 3,
//                 decoration: const InputDecoration(),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // ── Verification status card ──────────────────────────────────────────────
//   Widget _buildVerificationStatusCard(KycProvider provider) {
//     final status = provider.verificationStatus;
//     final hasStatus = status != null && status.isNotEmpty;

//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//         horizontal: _DS.cardPaddingH,
//         vertical: _DS.cardPaddingV,
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Padding(
//             padding: EdgeInsets.symmetric(vertical: 10),
//             child: Text(
//               'Verification Status(पडताळणी ची सद्यस्थिती):',
//               style: TextStyle(
//                 fontSize: _DS.labelFontSize,
//                 color: _DS.labelColor,
//                 fontWeight: FontWeight.w500,
//               ),
//             ),
//           ),
//           if (hasStatus) ...[
//             _StatusBadge(status: status!),
//             const SizedBox(height: 8),
//           ] else
//             const SizedBox(height: 28),
//           const Divider(color: _DS.divider, thickness: 1, height: 1),
//           const SizedBox(height: 4),
//         ],
//       ),
//     );
//   }

//   // ── CTA button ────────────────────────────────────────────────────────────
//   Widget _buildCtaButton(KycProvider provider) {
//     final status = provider.verificationStatus?.toLowerCase();

//     // ── 1. APPROVED ──────────────────────────────────────────────────────────
//     if (status == 'approved') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _viewCertificate,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: const Color(0xFF28A745),
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(_DS.buttonRadius),
//             ),
//             elevation: 3,
//             shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.workspace_premium, color: Colors.white, size: 18),
//                   SizedBox(width: 8),
//                   Text(
//                     'View Certificate',
//                     style: TextStyle(
//                       fontSize: 15.5,
//                       fontWeight: FontWeight.w700,
//                       color: Colors.white,
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: 3),
//               Text(
//                 'प्रमाणपत्र पहा',
//                 style: TextStyle(
//                   fontSize: 13,
//                   fontWeight: FontWeight.w500,
//                   color: Colors.white,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       );
//     }

//     // ── 2. PENDING ───────────────────────────────────────────────────────────
//     if (status == 'pending') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _showPendingInfoDialog,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: _DS.buttonBg,
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(_DS.buttonRadius),
//             ),
//             elevation: 2,
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text(
//                 'Verification In Progress',
//                 style: TextStyle(
//                   fontSize: 15,
//                   fontWeight: FontWeight.w700,
//                   color: _DS.buttonText,
//                 ),
//               ),
//               SizedBox(height: 3),
//               Text(
//                 'पडताळणी प्रगतीपथावर आहे',
//                 style: TextStyle(
//                   fontSize: 12.5,
//                   fontWeight: FontWeight.w500,
//                   color: _DS.buttonText,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       );
//     }

//     // ── 3. NORMAL / FIRST-TIME ───────────────────────────────────────────────
//     return SizedBox(
//       width: double.infinity,
//       child: ElevatedButton(
//         onPressed: provider.isLoading ? null : _proceed,
//         style: ElevatedButton.styleFrom(
//           backgroundColor: _DS.buttonBg,
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(_DS.buttonRadius),
//           ),
//           elevation: 3,
//           shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
//         ),
//         child: provider.isLoading
//             ? const SizedBox(
//                 height: 22,
//                 width: 22,
//                 child: CircularProgressIndicator(
//                   strokeWidth: 2.5,
//                   valueColor: AlwaysStoppedAnimation(Colors.white),
//                 ),
//               )
//             : Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text(
//                     'Generate Your Life Certificate',
//                     style: TextStyle(
//                       fontSize: 15.5,
//                       fontWeight: FontWeight.w700,
//                       color: _DS.buttonText,
//                     ),
//                   ),
//                   const SizedBox(height: 3),
//                   const Text(
//                     'जीवन प्रमाणपत्र तयार करा',
//                     style: TextStyle(
//                       fontSize: 13,
//                       fontWeight: FontWeight.w500,
//                       color: _DS.buttonText,
//                     ),
//                   ),
//                   const SizedBox(height: 2),
//                   Text(
//                     '(${provider.financialYear ?? '2026-2027'})',
//                     style: const TextStyle(
//                       fontSize: 13,
//                       fontWeight: FontWeight.w500,
//                       color: _DS.buttonText,
//                     ),
//                   ),
//                 ],
//               ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailsCard
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailsCard extends StatelessWidget {
//   final List<Widget> children;
//   const _DetailsCard({required this.children});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//         horizontal: _DS.cardPaddingH,
//         vertical: _DS.cardPaddingV,
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: children,
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailRow
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailRow extends StatelessWidget {
//   final String label;
//   final String value;
//   final bool showDivider;
//   final bool isLast;

//   const _DetailRow({
//     required this.label,
//     required this.value,
//     this.showDivider = false,
//     this.isLast = false,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Padding(
//           padding: EdgeInsets.only(
//             top: _DS.rowPaddingV,
//             bottom: isLast ? _DS.rowPaddingV : 2,
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 label,
//                 style: const TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 3),
//               Text(
//                 value,
//                 style: const TextStyle(
//                   fontSize: _DS.valueFontSize,
//                   color: _DS.valueColor,
//                   fontWeight: FontWeight.w700,
//                 ),
//               ),
//             ],
//           ),
//         ),
//         if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
//         if (showDivider) const SizedBox(height: 4),
//       ],
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _StatusBadge
// // ─────────────────────────────────────────────────────────────────────────────
// class _StatusBadge extends StatelessWidget {
//   final String status;
//   const _StatusBadge({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     final lower = status.toLowerCase();
//     Color bg, border, text;
//     IconData icon;
//     String label, marathi;

//     if (lower == 'approved') {
//       bg = const Color(0xFFE8F9EE);
//       border = const Color(0xFF34A853);
//       text = const Color(0xFF1E8740);
//       icon = Icons.check_circle_outline;
//       label = 'Approved';
//       marathi = 'मंजूर';
//     } else if (lower == 'pending') {
//       bg = const Color(0xFFEAF3FB);
//       border = _DS.buttonBg;
//       text = _DS.buttonBg;
//       icon = Icons.hourglass_bottom;
//       label = 'Verification In Progress';
//       marathi = 'पडताळणी प्रगतीपथावर आहे';
//     } else {
//       bg = const Color(0xFFF5F5F5);
//       border = const Color(0xFFBBBBBB);
//       text = const Color(0xFF666666);
//       icon = Icons.info_outline;
//       label = status;
//       marathi = '';
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
//       decoration: BoxDecoration(
//         color: bg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: border, width: 1.5),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(icon, color: text, size: 20),
//           const SizedBox(width: 8),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 label,
//                 style: TextStyle(
//                   color: text,
//                   fontWeight: FontWeight.w700,
//                   fontSize: 13.5,
//                 ),
//               ),
//               if (marathi.isNotEmpty)
//                 Text(marathi, style: TextStyle(color: text, fontSize: 11)),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';
// import '../screens/certificate_webview_screen.dart';
// import '../utils/helpers.dart';

// // ─────────────────────────────────────────────────────────────────────────────
// // Design tokens
// // ─────────────────────────────────────────────────────────────────────────────
// class _DS {
//   static const Color headerBg = Color(0xFF7BBDE4);
//   static const Color headerText = Colors.white;
//   static const Color pageBg = Color(0xFFF2F5FA);
//   static const Color cardBg = Colors.white;
//   static const Color cardBorder = Color(0xFF93C4E8);
//   static const double cardRadius = 12.0;
//   static const double cardBorderWidth = 1.5;
//   static const Color labelColor = Color(0xFF8A9BB0);
//   static const double labelFontSize = 13.0;
//   static const Color valueColor = Color(0xFF1A1A1A);
//   static const double valueFontSize = 15.5;
//   static const Color divider = Color(0xFFDDE4EE);
//   static const Color buttonBg = Color(0xFF3A9BDC);
//   static const Color buttonText = Colors.white;
//   static const double buttonRadius = 16.0;
//   static const double rowPaddingV = 12.0;
//   static const double cardPaddingH = 16.0;
//   static const double cardPaddingV = 4.0;
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Helper: build the certificate URL
// // ─────────────────────────────────────────────────────────────────────────────
// String _buildCertUrl(String? financialYear, int? certificateId) {
//   if (financialYear == null || certificateId == null) return '';
//   final yearPart = financialYear.replaceAll('-', '_');
//   return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Main Screen
// // ─────────────────────────────────────────────────────────────────────────────
// class PensionerDetailsScreen extends StatefulWidget {
//   const PensionerDetailsScreen({super.key});

//   @override
//   State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
// }

// class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
//   final _aadhaarController = TextEditingController();
//   final _addressController = TextEditingController();
//   String? _selectedGender;

//   @override
//   void initState() {
//     super.initState();
//     final provider = context.read<KycProvider>();
//     _aadhaarController.text = provider.aadhaarNumber ?? '';
//     _addressController.text = provider.address ?? '';
//     _selectedGender = provider.gender;
//   }

//   @override
//   void dispose() {
//     _aadhaarController.dispose();
//     _addressController.dispose();
//     super.dispose();
//   }

//   // ── "Generate Life Certificate" normal flow ────────────────────────────────
//   Future<void> _proceed() async {
//     final provider = context.read<KycProvider>();
//     final success = await provider.savePensionerDetails(
//       newAadhaar: _aadhaarController.text.trim(),
//       newAddress: _addressController.text.trim(),
//       newGender: _selectedGender,
//     );
//     if (!success || !mounted) return;
//     if (provider.shouldSkipAadhaarVerification) {
//       Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
//     } else {
//       Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
//     }
//   }

//   // ── "View Certificate" ─────────────────────────────────────────────────────
//   void _viewCertificate() {
//     final provider = context.read<KycProvider>();
//     final url = _buildCertUrl(provider.financialYear, provider.certificateId);

//     if (url.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('Certificate details not available. Please try again.'),
//           backgroundColor: Colors.red,
//         ),
//       );
//       return;
//     }

//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (_) => CertificateWebViewScreen(url: url),
//       ),
//     );
//   }

//   // ── "Verification In Progress" dialog ─────────────────────────────────────
//   // Used by both the pending CTA button tap.
//   void _showPendingDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(15),
//           ),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(ctx).pop(),
//               child: const Text(
//                 'OK',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── Pending back-navigation dialog ────────────────────────────────────────
//   // Shows the dialog and on OK navigates to the first route.
//   // Returns a Future so WillPopScope can await it and always return false
//   // (we handle navigation manually).
//   Future<void> _showPendingBackDialog() async {
//     await showDialog(
//       context: context,
//       barrierDismissible: false, // force user to tap OK
//       builder: (BuildContext ctx) {
//         return AlertDialog(
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(15),
//           ),
//           title: const Row(
//             children: [
//               Icon(Icons.info_outline, color: Colors.orange, size: 28),
//               SizedBox(width: 10),
//               Expanded(
//                 child: Text(
//                   'Verification Status',
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ],
//           ),
//           content: const Text(
//             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
//             style: TextStyle(fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//           actions: [
//             TextButton(
//               onPressed: () {
//                 Navigator.of(ctx).pop(); // close the dialog
//                 // Navigate to the very first route (PPO entry screen).
//                 Navigator.of(context).popUntil((route) => route.isFirst);
//               },
//               child: const Text(
//                 'OK',
//                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // ── WillPopScope handler (hardware back button) ────────────────────────────
//   Future<bool> _onWillPop(String? status) async {
//     if (status?.toLowerCase() == 'pending') {
//       // Show dialog; navigation is handled inside _showPendingBackDialog.
//       await _showPendingBackDialog();
//       // Always return false — we already navigated manually inside the dialog.
//       return false;
//     }
//     // Non-pending: allow normal back navigation.
//     return true;
//   }

//   // ── AppBar back-arrow handler ──────────────────────────────────────────────
//   // Separate from WillPopScope so it is always reliable regardless of
//   // WillPopScope's async behaviour.
//   void _onAppBarBack(String? status) {
//     if (status?.toLowerCase() == 'pending') {
//       // Show the pending dialog; it handles navigation on OK.
//       _showPendingBackDialog();
//     } else {
//       Navigator.of(context).pop();
//     }
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Build
//   // ─────────────────────────────────────────────────────────────────────────
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<KycProvider>(
//       builder: (_, provider, __) {
//         final status = provider.verificationStatus;

//         return WillPopScope(
//           onWillPop: () => _onWillPop(status),
//           child: Scaffold(
//             backgroundColor: _DS.pageBg,
//             appBar: AppBar(
//               backgroundColor: _DS.headerBg,
//               elevation: 0,
//               centerTitle: true,
//               // ✅ FIX: Use dedicated _onAppBarBack so pending status always
//               // shows the dialog instead of closing/crashing the app.
//               leading: IconButton(
//                 icon: const Icon(Icons.arrow_back, color: _DS.headerText),
//                 onPressed: () => _onAppBarBack(status),
//               ),
//               title: const Text(
//                 'Pensioner Details [Step-2]',
//                 style: TextStyle(
//                   color: _DS.headerText,
//                   fontSize: 18,
//                   fontWeight: FontWeight.w700,
//                 ),
//               ),
//             ),
//             body: SingleChildScrollView(
//               padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 children: [
//                   // ── Details card ────────────────────────────────────────
//                   if (provider.isKycCompleted || provider.isReturningPensioner)
//                     _buildReadOnlyCard(provider)
//                   else
//                     _buildEditableForm(provider),

//                   const SizedBox(height: 14),

//                   // ── Verification Status card ────────────────────────────
//                   _buildVerificationStatusCard(provider),

//                   const SizedBox(height: 18),

//                   // ── CTA Button ──────────────────────────────────────────
//                   _buildCtaButton(provider),

//                   // ── Error ───────────────────────────────────────────────
//                   if (provider.error != null) ...[
//                     const SizedBox(height: 14),
//                     Container(
//                       padding: const EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: Colors.red.withValues(alpha: 0.08),
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Text(
//                         provider.error!,
//                         style: const TextStyle(color: Colors.red),
//                         textAlign: TextAlign.center,
//                       ),
//                     ),
//                   ],
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // ── Read-only details card ────────────────────────────────────────────────
//   Widget _buildReadOnlyCard(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         _DetailRow(
//           label: 'Aadhar Number(आधार नंबर):',
//           value: maskAadhaar(provider.aadhaarNumber),
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Pension Type(पेन्शन प्रकार):',
//           value: provider.pensionType ?? '—',
//           showDivider: true,
//         ),
//         _DetailRow(
//           label: 'Address(पत्ता):',
//           value: provider.address ?? '—',
//           isLast: true,
//         ),
//       ],
//     );
//   }

//   // ── Editable form card ────────────────────────────────────────────────────
//   Widget _buildEditableForm(KycProvider provider) {
//     return _DetailsCard(
//       children: [
//         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
//         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Aadhar Number(आधार नंबर):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _aadhaarController,
//                 keyboardType: TextInputType.number,
//                 maxLength: 12,
//                 decoration: const InputDecoration(counterText: ''),
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Gender:',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               DropdownButtonFormField<String>(
//                 value: _selectedGender,
//                 decoration: const InputDecoration(),
//                 items: const [
//                   DropdownMenuItem(value: 'Male', child: Text('Male')),
//                   DropdownMenuItem(value: 'Female', child: Text('Female')),
//                   DropdownMenuItem(value: 'Other', child: Text('Other')),
//                 ],
//                 onChanged: (val) => setState(() => _selectedGender = val),
//               ),
//             ],
//           ),
//         ),
//         Padding(
//           padding: const EdgeInsets.only(top: 8, bottom: 4),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Address(पत्ता):',
//                 style: TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 4),
//               TextField(
//                 controller: _addressController,
//                 maxLines: 3,
//                 decoration: const InputDecoration(),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // ── Verification status card ──────────────────────────────────────────────
//   Widget _buildVerificationStatusCard(KycProvider provider) {
//     final status = provider.verificationStatus;
//     final hasStatus = status != null && status.isNotEmpty;

//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//         horizontal: _DS.cardPaddingH,
//         vertical: _DS.cardPaddingV,
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Padding(
//             padding: EdgeInsets.symmetric(vertical: 10),
//             child: Text(
//               'Verification Status(पडताळणी ची सद्यस्थिती):',
//               style: TextStyle(
//                 fontSize: _DS.labelFontSize,
//                 color: _DS.labelColor,
//                 fontWeight: FontWeight.w500,
//               ),
//             ),
//           ),
//           if (hasStatus) ...[
//             _StatusBadge(status: status!),
//             const SizedBox(height: 8),
//           ] else
//             const SizedBox(height: 28),
//           const Divider(color: _DS.divider, thickness: 1, height: 1),
//           const SizedBox(height: 4),
//         ],
//       ),
//     );
//   }

//   // ── CTA button ────────────────────────────────────────────────────────────
//   Widget _buildCtaButton(KycProvider provider) {
//     final status = provider.verificationStatus?.toLowerCase();

//     // ── 1. APPROVED ──────────────────────────────────────────────────────────
//     if (status == 'approved') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _viewCertificate,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: const Color(0xFF28A745),
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(_DS.buttonRadius),
//             ),
//             elevation: 3,
//             shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.workspace_premium, color: Colors.white, size: 18),
//                   SizedBox(width: 8),
//                   Text(
//                     'View Certificate',
//                     style: TextStyle(
//                       fontSize: 15.5,
//                       fontWeight: FontWeight.w700,
//                       color: Colors.white,
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: 3),
//               Text(
//                 'प्रमाणपत्र पहा',
//                 style: TextStyle(
//                   fontSize: 13,
//                   fontWeight: FontWeight.w500,
//                   color: Colors.white,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       );
//     }

//     // ── 2. PENDING ───────────────────────────────────────────────────────────
//     if (status == 'pending') {
//       return SizedBox(
//         width: double.infinity,
//         child: ElevatedButton(
//           onPressed: _showPendingDialog,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: _DS.buttonBg,
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(_DS.buttonRadius),
//             ),
//             elevation: 2,
//           ),
//           child: const Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text(
//                 'Verification In Progress',
//                 style: TextStyle(
//                   fontSize: 15,
//                   fontWeight: FontWeight.w700,
//                   color: _DS.buttonText,
//                 ),
//               ),
//               SizedBox(height: 3),
//               Text(
//                 'पडताळणी प्रगतीपथावर आहे',
//                 style: TextStyle(
//                   fontSize: 12.5,
//                   fontWeight: FontWeight.w500,
//                   color: _DS.buttonText,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       );
//     }

//     // ── 3. NORMAL / FIRST-TIME ───────────────────────────────────────────────
//     return SizedBox(
//       width: double.infinity,
//       child: ElevatedButton(
//         onPressed: provider.isLoading ? null : _proceed,
//         style: ElevatedButton.styleFrom(
//           backgroundColor: _DS.buttonBg,
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(_DS.buttonRadius),
//           ),
//           elevation: 3,
//           shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
//         ),
//         child: provider.isLoading
//             ? const SizedBox(
//                 height: 22,
//                 width: 22,
//                 child: CircularProgressIndicator(
//                   strokeWidth: 2.5,
//                   valueColor: AlwaysStoppedAnimation(Colors.white),
//                 ),
//               )
//             : Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   const Text(
//                     'Generate Your Life Certificate',
//                     style: TextStyle(
//                       fontSize: 15.5,
//                       fontWeight: FontWeight.w700,
//                       color: _DS.buttonText,
//                     ),
//                   ),
//                   const SizedBox(height: 3),
//                   const Text(
//                     'जीवन प्रमाणपत्र तयार करा',
//                     style: TextStyle(
//                       fontSize: 13,
//                       fontWeight: FontWeight.w500,
//                       color: _DS.buttonText,
//                     ),
//                   ),
//                   const SizedBox(height: 2),
//                   Text(
//                     '(${provider.financialYear ?? '2026-2027'})',
//                     style: const TextStyle(
//                       fontSize: 13,
//                       fontWeight: FontWeight.w500,
//                       color: _DS.buttonText,
//                     ),
//                   ),
//                 ],
//               ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailsCard
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailsCard extends StatelessWidget {
//   final List<Widget> children;
//   const _DetailsCard({required this.children});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: BoxDecoration(
//         color: _DS.cardBg,
//         borderRadius: BorderRadius.circular(_DS.cardRadius),
//         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
//       ),
//       padding: const EdgeInsets.symmetric(
//         horizontal: _DS.cardPaddingH,
//         vertical: _DS.cardPaddingV,
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: children,
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _DetailRow
// // ─────────────────────────────────────────────────────────────────────────────
// class _DetailRow extends StatelessWidget {
//   final String label;
//   final String value;
//   final bool showDivider;
//   final bool isLast;

//   const _DetailRow({
//     required this.label,
//     required this.value,
//     this.showDivider = false,
//     this.isLast = false,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Padding(
//           padding: EdgeInsets.only(
//             top: _DS.rowPaddingV,
//             bottom: isLast ? _DS.rowPaddingV : 2,
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 label,
//                 style: const TextStyle(
//                   fontSize: _DS.labelFontSize,
//                   color: _DS.labelColor,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               const SizedBox(height: 3),
//               Text(
//                 value,
//                 style: const TextStyle(
//                   fontSize: _DS.valueFontSize,
//                   color: _DS.valueColor,
//                   fontWeight: FontWeight.w700,
//                 ),
//               ),
//             ],
//           ),
//         ),
//         if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
//         if (showDivider) const SizedBox(height: 4),
//       ],
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // _StatusBadge
// // ─────────────────────────────────────────────────────────────────────────────
// class _StatusBadge extends StatelessWidget {
//   final String status;
//   const _StatusBadge({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     final lower = status.toLowerCase();
//     Color bg, border, text;
//     IconData icon;
//     String label, marathi;

//     if (lower == 'approved') {
//       bg = const Color(0xFFE8F9EE);
//       border = const Color(0xFF34A853);
//       text = const Color(0xFF1E8740);
//       icon = Icons.check_circle_outline;
//       label = 'Approved';
//       marathi = 'मंजूर';
//     } else if (lower == 'pending') {
//       bg = const Color(0xFFEAF3FB);
//       border = _DS.buttonBg;
//       text = _DS.buttonBg;
//       icon = Icons.hourglass_bottom;
//       label = 'Verification In Progress';
//       marathi = 'पडताळणी प्रगतीपथावर आहे';
//     } else {
//       bg = const Color(0xFFF5F5F5);
//       border = const Color(0xFFBBBBBB);
//       text = const Color(0xFF666666);
//       icon = Icons.info_outline;
//       label = status;
//       marathi = '';
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
//       decoration: BoxDecoration(
//         color: bg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: border, width: 1.5),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(icon, color: text, size: 20),
//           const SizedBox(width: 8),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 label,
//                 style: TextStyle(
//                   color: text,
//                   fontWeight: FontWeight.w700,
//                   fontSize: 13.5,
//                 ),
//               ),
//               if (marathi.isNotEmpty)
//                 Text(marathi, style: TextStyle(color: text, fontSize: 11)),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

// // import 'package:flutter/material.dart';
// // import 'package:provider/provider.dart';

// // import '../config/routes.dart';
// // import '../providers/kyc_provider.dart';
// // import '../screens/certificate_webview_screen.dart';
// // import '../utils/helpers.dart';

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Design tokens
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _DS {
// //   static const Color headerBg = Color(0xFF7BBDE4);
// //   static const Color headerText = Colors.white;
// //   static const Color pageBg = Color(0xFFF2F5FA);
// //   static const Color cardBg = Colors.white;
// //   static const Color cardBorder = Color(0xFF93C4E8);
// //   static const double cardRadius = 12.0;
// //   static const double cardBorderWidth = 1.5;
// //   static const Color labelColor = Color(0xFF8A9BB0);
// //   static const double labelFontSize = 13.0;
// //   static const Color valueColor = Color(0xFF1A1A1A);
// //   static const double valueFontSize = 15.5;
// //   static const Color divider = Color(0xFFDDE4EE);
// //   static const Color buttonBg = Color(0xFF3A9BDC);
// //   static const Color buttonText = Colors.white;
// //   static const double buttonRadius = 16.0;
// //   static const double rowPaddingV = 12.0;
// //   static const double cardPaddingH = 16.0;
// //   static const double cardPaddingV = 4.0;
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Helper: build the certificate URL
// // // ─────────────────────────────────────────────────────────────────────────────
// // String _buildCertUrl(String? financialYear, int? certificateId) {
// //   if (financialYear == null || certificateId == null) return '';
// //   final yearPart = financialYear.replaceAll('-', '_');
// //   return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Main Screen
// // // ─────────────────────────────────────────────────────────────────────────────
// // class PensionerDetailsScreen extends StatefulWidget {
// //   const PensionerDetailsScreen({super.key});

// //   @override
// //   State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
// // }

// // class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
// //   final _aadhaarController = TextEditingController();
// //   final _addressController = TextEditingController();
// //   String? _selectedGender;

// //   @override
// //   void initState() {
// //     super.initState();
// //     final provider = context.read<KycProvider>();
// //     _aadhaarController.text = provider.aadhaarNumber ?? '';
// //     _addressController.text = provider.address ?? '';
// //     _selectedGender = provider.gender;
// //   }

// //   @override
// //   void dispose() {
// //     _aadhaarController.dispose();
// //     _addressController.dispose();
// //     super.dispose();
// //   }

// //   // ── "Generate Life Certificate" normal flow ────────────────────────────────
// //   Future<void> _proceed() async {
// //     final provider = context.read<KycProvider>();
// //     final success = await provider.savePensionerDetails(
// //       newAadhaar: _aadhaarController.text.trim(),
// //       newAddress: _addressController.text.trim(),
// //       newGender: _selectedGender,
// //     );
// //     if (!success || !mounted) return;
// //     if (provider.shouldSkipAadhaarVerification) {
// //       Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
// //     } else {
// //       Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
// //     }
// //   }

// //   // ── "View Certificate" ─────────────────────────────────────────────────────
// //   void _viewCertificate() {
// //     final provider = context.read<KycProvider>();
// //     final url = _buildCertUrl(provider.financialYear, provider.certificateId);

// //     if (url.isEmpty) {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         const SnackBar(
// //           content: Text('Certificate details not available. Please try again.'),
// //           backgroundColor: Colors.red,
// //         ),
// //       );
// //       return;
// //     }

// //     Navigator.push(
// //       context,
// //       MaterialPageRoute(
// //         builder: (_) => CertificateWebViewScreen(url: url),
// //       ),
// //     );
// //   }

// //   // ── "Verification In Progress" dialog ─────────────────────────────────────
// //   // FIX: Extracted into a reusable method so both the back-arrow handler
// //   // and the "Verification In Progress" button can call it.
// //   void _showPendingDialog() {
// //     showDialog(
// //       context: context,
// //       builder: (BuildContext ctx) {
// //         return AlertDialog(
// //           shape: RoundedRectangleBorder(
// //             borderRadius: BorderRadius.circular(15),
// //           ),
// //           title: const Row(
// //             children: [
// //               Icon(Icons.info_outline, color: Colors.orange, size: 28),
// //               SizedBox(width: 10),
// //               Expanded(
// //                 child: Text(
// //                   'Verification Status',
// //                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
// //                 ),
// //               ),
// //             ],
// //           ),
// //           content: const Text(
// //             'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
// //             style: TextStyle(fontSize: 16),
// //             textAlign: TextAlign.center,
// //           ),
// //           actions: [
// //             TextButton(
// //               onPressed: () => Navigator.of(ctx).pop(),
// //               child: const Text(
// //                 'OK',
// //                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
// //               ),
// //             ),
// //           ],
// //         );
// //       },
// //     );
// //   }

// //   // ── Handle back navigation for pending status ──────────────────────────────
// //   // FIX: When status is "pending" and the user taps the back arrow,
// //   // show the dialog first; dismissing it then pops back to the very
// //   // first route (PPO entry) instead of closing the app.
// //   Future<bool> _onWillPop(String? status) async {
// //     if (status?.toLowerCase() == 'pending') {
// //       await showDialog(
// //         context: context,
// //         builder: (BuildContext ctx) {
// //           return AlertDialog(
// //             shape: RoundedRectangleBorder(
// //               borderRadius: BorderRadius.circular(15),
// //             ),
// //             title: const Row(
// //               children: [
// //                 Icon(Icons.info_outline, color: Colors.orange, size: 28),
// //                 SizedBox(width: 10),
// //                 Expanded(
// //                   child: Text(
// //                     'Verification Status',
// //                     style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //             content: const Text(
// //               'Your verification is in progress.\nतुमची पडताळणी प्रक्रियेत आहे.',
// //               style: TextStyle(fontSize: 16),
// //               textAlign: TextAlign.center,
// //             ),
// //             actions: [
// //               TextButton(
// //                 // After OK, pop the dialog AND navigate to the root (PPO entry).
// //                 onPressed: () {
// //                   Navigator.of(ctx).pop(); // close dialog
// //                   // Pop all routes until the very first one (PPO entry screen).
// //                   Navigator.of(context).popUntil((route) => route.isFirst);
// //                 },
// //                 child: const Text(
// //                   'OK',
// //                   style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
// //                 ),
// //               ),
// //             ],
// //           );
// //         },
// //       );
// //       // Return false so WillPopScope does NOT also pop; we handled it manually.
// //       return false;
// //     }
// //     // For non-pending statuses allow normal back navigation.
// //     return true;
// //   }

// //   // ─────────────────────────────────────────────────────────────────────────
// //   // Build
// //   // ─────────────────────────────────────────────────────────────────────────
// //   @override
// //   Widget build(BuildContext context) {
// //     return Consumer<KycProvider>(
// //       builder: (_, provider, __) {
// //         final status = provider.verificationStatus;

// //         // FIX: Wrap the entire Scaffold in WillPopScope so both the
// //         // hardware back button and the AppBar back arrow are intercepted.
// //         return WillPopScope(
// //           onWillPop: () => _onWillPop(status),
// //           child: Scaffold(
// //             backgroundColor: _DS.pageBg,
// //             appBar: AppBar(
// //               backgroundColor: _DS.headerBg,
// //               elevation: 0,
// //               centerTitle: true,
// //               // FIX: Replace maybePop with a manual call that respects
// //               // the pending-status guard.
// //               leading: IconButton(
// //                 icon: const Icon(Icons.arrow_back, color: _DS.headerText),
// //                 onPressed: () async {
// //                   final shouldPop = await _onWillPop(status);
// //                   if (shouldPop && mounted) Navigator.of(context).pop();
// //                 },
// //               ),
// //               title: const Text(
// //                 'Pensioner Details [Step-2]',
// //                 style: TextStyle(
// //                   color: _DS.headerText,
// //                   fontSize: 18,
// //                   fontWeight: FontWeight.w700,
// //                 ),
// //               ),
// //             ),
// //             body: SingleChildScrollView(
// //               padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
// //               child: Column(
// //                 crossAxisAlignment: CrossAxisAlignment.stretch,
// //                 children: [
// //                   // ── Details card ────────────────────────────────────────
// //                   if (provider.isKycCompleted || provider.isReturningPensioner)
// //                     _buildReadOnlyCard(provider)
// //                   else
// //                     _buildEditableForm(provider),

// //                   const SizedBox(height: 14),

// //                   // ── Verification Status card ────────────────────────────
// //                   _buildVerificationStatusCard(provider),

// //                   const SizedBox(height: 18),

// //                   // ── CTA Button ──────────────────────────────────────────
// //                   _buildCtaButton(provider),

// //                   // ── Error ───────────────────────────────────────────────
// //                   if (provider.error != null) ...[
// //                     const SizedBox(height: 14),
// //                     Container(
// //                       padding: const EdgeInsets.all(12),
// //                       decoration: BoxDecoration(
// //                         color: Colors.red.withValues(alpha: 0.08),
// //                         borderRadius: BorderRadius.circular(10),
// //                       ),
// //                       child: Text(
// //                         provider.error!,
// //                         style: const TextStyle(color: Colors.red),
// //                         textAlign: TextAlign.center,
// //                       ),
// //                     ),
// //                   ],
// //                 ],
// //               ),
// //             ),
// //           ),
// //         );
// //       },
// //     );
// //   }

// //   // ── Read-only details card ────────────────────────────────────────────────
// //   Widget _buildReadOnlyCard(KycProvider provider) {
// //     return _DetailsCard(
// //       children: [
// //         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
// //         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
// //         _DetailRow(
// //           label: 'Aadhar Number(आधार नंबर):',
// //           value: maskAadhaar(provider.aadhaarNumber),
// //           showDivider: true,
// //         ),
// //         _DetailRow(
// //           label: 'Pension Type(पेन्शन प्रकार):',
// //           value: provider.pensionType ?? '—',
// //           showDivider: true,
// //         ),
// //         _DetailRow(
// //           label: 'Address(पत्ता):',
// //           value: provider.address ?? '—',
// //           isLast: true,
// //         ),
// //       ],
// //     );
// //   }

// //   // ── Editable form card ────────────────────────────────────────────────────
// //   Widget _buildEditableForm(KycProvider provider) {
// //     return _DetailsCard(
// //       children: [
// //         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
// //         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
// //         Padding(
// //           padding: const EdgeInsets.symmetric(vertical: 8),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               const Text(
// //                 'Aadhar Number(आधार नंबर):',
// //                 style: TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 4),
// //               TextField(
// //                 controller: _aadhaarController,
// //                 keyboardType: TextInputType.number,
// //                 maxLength: 12,
// //                 decoration: const InputDecoration(counterText: ''),
// //               ),
// //             ],
// //           ),
// //         ),
// //         Padding(
// //           padding: const EdgeInsets.symmetric(vertical: 8),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               const Text(
// //                 'Gender:',
// //                 style: TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 4),
// //               DropdownButtonFormField<String>(
// //                 value: _selectedGender,
// //                 decoration: const InputDecoration(),
// //                 items: const [
// //                   DropdownMenuItem(value: 'Male', child: Text('Male')),
// //                   DropdownMenuItem(value: 'Female', child: Text('Female')),
// //                   DropdownMenuItem(value: 'Other', child: Text('Other')),
// //                 ],
// //                 onChanged: (val) => setState(() => _selectedGender = val),
// //               ),
// //             ],
// //           ),
// //         ),
// //         Padding(
// //           padding: const EdgeInsets.only(top: 8, bottom: 4),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               const Text(
// //                 'Address(पत्ता):',
// //                 style: TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 4),
// //               TextField(
// //                 controller: _addressController,
// //                 maxLines: 3,
// //                 decoration: const InputDecoration(),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ],
// //     );
// //   }

// //   // ── Verification status card ──────────────────────────────────────────────
// //   Widget _buildVerificationStatusCard(KycProvider provider) {
// //     final status = provider.verificationStatus;
// //     final hasStatus = status != null && status.isNotEmpty;

// //     return Container(
// //       decoration: BoxDecoration(
// //         color: _DS.cardBg,
// //         borderRadius: BorderRadius.circular(_DS.cardRadius),
// //         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
// //       ),
// //       padding: const EdgeInsets.symmetric(
// //         horizontal: _DS.cardPaddingH,
// //         vertical: _DS.cardPaddingV,
// //       ),
// //       child: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //           const Padding(
// //             padding: EdgeInsets.symmetric(vertical: 10),
// //             child: Text(
// //               'Verification Status(पडताळणी ची सद्यस्थिती):',
// //               style: TextStyle(
// //                 fontSize: _DS.labelFontSize,
// //                 color: _DS.labelColor,
// //                 fontWeight: FontWeight.w500,
// //               ),
// //             ),
// //           ),
// //           if (hasStatus) ...[
// //             _StatusBadge(status: status!),
// //             const SizedBox(height: 8),
// //           ] else
// //             const SizedBox(height: 28),
// //           const Divider(color: _DS.divider, thickness: 1, height: 1),
// //           const SizedBox(height: 4),
// //         ],
// //       ),
// //     );
// //   }

// //   // ── CTA button ────────────────────────────────────────────────────────────
// //   Widget _buildCtaButton(KycProvider provider) {
// //     final status = provider.verificationStatus?.toLowerCase();

// //     // ── 1. APPROVED ──────────────────────────────────────────────────────────
// //     if (status == 'approved') {
// //       return SizedBox(
// //         width: double.infinity,
// //         child: ElevatedButton(
// //           onPressed: _viewCertificate,
// //           style: ElevatedButton.styleFrom(
// //             backgroundColor: const Color(0xFF28A745),
// //             padding: const EdgeInsets.symmetric(vertical: 16),
// //             shape: RoundedRectangleBorder(
// //               borderRadius: BorderRadius.circular(_DS.buttonRadius),
// //             ),
// //             elevation: 3,
// //             shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
// //           ),
// //           child: const Column(
// //             mainAxisSize: MainAxisSize.min,
// //             children: [
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: [
// //                   Icon(Icons.workspace_premium, color: Colors.white, size: 18),
// //                   SizedBox(width: 8),
// //                   Text(
// //                     'View Certificate',
// //                     style: TextStyle(
// //                       fontSize: 15.5,
// //                       fontWeight: FontWeight.w700,
// //                       color: Colors.white,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //               SizedBox(height: 3),
// //               Text(
// //                 'प्रमाणपत्र पहा',
// //                 style: TextStyle(
// //                   fontSize: 13,
// //                   fontWeight: FontWeight.w500,
// //                   color: Colors.white,
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }

// //     // ── 2. PENDING ───────────────────────────────────────────────────────────
// //     // FIX: onPressed now calls _showPendingDialog() instead of null,
// //     // so tapping the button shows the "Verification In Progress" dialog.
// //     if (status == 'pending') {
// //       return SizedBox(
// //         width: double.infinity,
// //         child: ElevatedButton(
// //           onPressed: _showPendingDialog, // ← was null, now shows dialog
// //           style: ElevatedButton.styleFrom(
// //             backgroundColor: _DS.buttonBg,
// //             padding: const EdgeInsets.symmetric(vertical: 16),
// //             shape: RoundedRectangleBorder(
// //               borderRadius: BorderRadius.circular(_DS.buttonRadius),
// //             ),
// //             elevation: 2,
// //           ),
// //           child: const Column(
// //             mainAxisSize: MainAxisSize.min,
// //             children: [
// //               Text(
// //                 'Verification In Progress',
// //                 style: TextStyle(
// //                   fontSize: 15,
// //                   fontWeight: FontWeight.w700,
// //                   color: _DS.buttonText,
// //                 ),
// //               ),
// //               SizedBox(height: 3),
// //               Text(
// //                 'पडताळणी प्रगतीपथावर आहे',
// //                 style: TextStyle(
// //                   fontSize: 12.5,
// //                   fontWeight: FontWeight.w500,
// //                   color: _DS.buttonText,
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }

// //     // ── 3. NORMAL / FIRST-TIME ───────────────────────────────────────────────
// //     return SizedBox(
// //       width: double.infinity,
// //       child: ElevatedButton(
// //         onPressed: provider.isLoading ? null : _proceed,
// //         style: ElevatedButton.styleFrom(
// //           backgroundColor: _DS.buttonBg,
// //           padding: const EdgeInsets.symmetric(vertical: 16),
// //           shape: RoundedRectangleBorder(
// //             borderRadius: BorderRadius.circular(_DS.buttonRadius),
// //           ),
// //           elevation: 3,
// //           shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
// //         ),
// //         child: provider.isLoading
// //             ? const SizedBox(
// //                 height: 22,
// //                 width: 22,
// //                 child: CircularProgressIndicator(
// //                   strokeWidth: 2.5,
// //                   valueColor: AlwaysStoppedAnimation(Colors.white),
// //                 ),
// //               )
// //             : Column(
// //                 mainAxisSize: MainAxisSize.min,
// //                 children: [
// //                   const Text(
// //                     'Generate Your Life Certificate',
// //                     style: TextStyle(
// //                       fontSize: 15.5,
// //                       fontWeight: FontWeight.w700,
// //                       color: _DS.buttonText,
// //                     ),
// //                   ),
// //                   const SizedBox(height: 3),
// //                   const Text(
// //                     'जीवन प्रमाणपत्र तयार करा',
// //                     style: TextStyle(
// //                       fontSize: 13,
// //                       fontWeight: FontWeight.w500,
// //                       color: _DS.buttonText,
// //                     ),
// //                   ),
// //                   const SizedBox(height: 2),
// //                   Text(
// //                     '(${provider.financialYear ?? '2026-2027'})',
// //                     style: const TextStyle(
// //                       fontSize: 13,
// //                       fontWeight: FontWeight.w500,
// //                       color: _DS.buttonText,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //       ),
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // _DetailsCard
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _DetailsCard extends StatelessWidget {
// //   final List<Widget> children;
// //   const _DetailsCard({required this.children});

// //   @override
// //   Widget build(BuildContext context) {
// //     return Container(
// //       decoration: BoxDecoration(
// //         color: _DS.cardBg,
// //         borderRadius: BorderRadius.circular(_DS.cardRadius),
// //         border: Border.all(color: _DS.cardBorder, width: _DS.cardBorderWidth),
// //       ),
// //       padding: const EdgeInsets.symmetric(
// //         horizontal: _DS.cardPaddingH,
// //         vertical: _DS.cardPaddingV,
// //       ),
// //       child: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: children,
// //       ),
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // _DetailRow
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _DetailRow extends StatelessWidget {
// //   final String label;
// //   final String value;
// //   final bool showDivider;
// //   final bool isLast;

// //   const _DetailRow({
// //     required this.label,
// //     required this.value,
// //     this.showDivider = false,
// //     this.isLast = false,
// //   });

// //   @override
// //   Widget build(BuildContext context) {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         Padding(
// //           padding: EdgeInsets.only(
// //             top: _DS.rowPaddingV,
// //             bottom: isLast ? _DS.rowPaddingV : 2,
// //           ),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 label,
// //                 style: const TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 3),
// //               Text(
// //                 value,
// //                 style: const TextStyle(
// //                   fontSize: _DS.valueFontSize,
// //                   color: _DS.valueColor,
// //                   fontWeight: FontWeight.w700,
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //         if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
// //         if (showDivider) const SizedBox(height: 4),
// //       ],
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // _StatusBadge
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _StatusBadge extends StatelessWidget {
// //   final String status;
// //   const _StatusBadge({required this.status});

// //   @override
// //   Widget build(BuildContext context) {
// //     final lower = status.toLowerCase();
// //     Color bg, border, text;
// //     IconData icon;
// //     String label, marathi;

// //     if (lower == 'approved') {
// //       bg = const Color(0xFFE8F9EE);
// //       border = const Color(0xFF34A853);
// //       text = const Color(0xFF1E8740);
// //       icon = Icons.check_circle_outline;
// //       label = 'Approved';
// //       marathi = 'मंजूर';
// //     } else if (lower == 'pending') {
// //       bg = const Color(0xFFEAF3FB);
// //       border = _DS.buttonBg;
// //       text = _DS.buttonBg;
// //       icon = Icons.hourglass_bottom;
// //       label = 'Verification In Progress';
// //       marathi = 'पडताळणी प्रगतीपथावर आहे';
// //     } else {
// //       bg = const Color(0xFFF5F5F5);
// //       border = const Color(0xFFBBBBBB);
// //       text = const Color(0xFF666666);
// //       icon = Icons.info_outline;
// //       label = status;
// //       marathi = '';
// //     }

// //     return Container(
// //       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
// //       decoration: BoxDecoration(
// //         color: bg,
// //         borderRadius: BorderRadius.circular(10),
// //         border: Border.all(color: border, width: 1.5),
// //       ),
// //       child: Row(
// //         mainAxisSize: MainAxisSize.min,
// //         children: [
// //           Icon(icon, color: text, size: 20),
// //           const SizedBox(width: 8),
// //           Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 label,
// //                 style: TextStyle(
// //                   color: text,
// //                   fontWeight: FontWeight.w700,
// //                   fontSize: 13.5,
// //                 ),
// //               ),
// //               if (marathi.isNotEmpty)
// //                 Text(marathi, style: TextStyle(color: text, fontSize: 11)),
// //             ],
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }

// // import 'package:flutter/material.dart';
// // import 'package:provider/provider.dart';

// // import '../config/routes.dart';
// // import '../providers/kyc_provider.dart';
// // import '../screens/certificate_webview_screen.dart'; // ← add this import
// // import '../utils/helpers.dart';

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Design tokens
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _DS {
// //   static const Color headerBg = Color(0xFF7BBDE4);
// //   static const Color headerText = Colors.white;
// //   static const Color pageBg = Color(0xFFF2F5FA);
// //   static const Color cardBg = Colors.white;
// //   static const Color cardBorder = Color(0xFF93C4E8);
// //   static const double cardRadius = 12.0;
// //   static const double cardBorderWidth = 1.5;
// //   static const Color labelColor = Color(0xFF8A9BB0);
// //   static const double labelFontSize = 13.0;
// //   static const Color valueColor = Color(0xFF1A1A1A);
// //   static const double valueFontSize = 15.5;
// //   static const Color divider = Color(0xFFDDE4EE);
// //   static const Color buttonBg = Color(0xFF3A9BDC);
// //   static const Color buttonText = Colors.white;
// //   static const double buttonRadius = 16.0;
// //   static const double rowPaddingV = 12.0;
// //   static const double cardPaddingH = 16.0;
// //   static const double cardPaddingV = 4.0;
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Helper: build the certificate URL
// // //
// // // API response example:
// // //   financialYear : "2026-2027"   (may use dash or underscore)
// // //   certificateId : 12615
// // //
// // // Target URL:
// // //   https://lc.pcmcpensioner.in/Home/view/?lc=2026_2027_12615
// // // ─────────────────────────────────────────────────────────────────────────────
// // String _buildCertUrl(String? financialYear, int? certificateId) {
// //   if (financialYear == null || certificateId == null) return '';
// //   final yearPart = financialYear.replaceAll('-', '_');
// //   return 'https://lc.pcmcpensioner.in/Home/view/?lc=${yearPart}_$certificateId';
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Main Screen
// // // ─────────────────────────────────────────────────────────────────────────────
// // class PensionerDetailsScreen extends StatefulWidget {
// //   const PensionerDetailsScreen({super.key});

// //   @override
// //   State<PensionerDetailsScreen> createState() => _PensionerDetailsScreenState();
// // }

// // class _PensionerDetailsScreenState extends State<PensionerDetailsScreen> {
// //   final _aadhaarController = TextEditingController();
// //   final _addressController = TextEditingController();
// //   String? _selectedGender;

// //   @override
// //   void initState() {
// //     super.initState();
// //     final provider = context.read<KycProvider>();
// //     _aadhaarController.text = provider.aadhaarNumber ?? '';
// //     _addressController.text = provider.address ?? '';
// //     _selectedGender = provider.gender;
// //   }

// //   @override
// //   void dispose() {
// //     _aadhaarController.dispose();
// //     _addressController.dispose();
// //     super.dispose();
// //   }

// //   // ── "Generate Life Certificate" normal flow ────────────────────────────────
// //   Future<void> _proceed() async {
// //     final provider = context.read<KycProvider>();
// //     final success = await provider.savePensionerDetails(
// //       newAadhaar: _aadhaarController.text.trim(),
// //       newAddress: _addressController.text.trim(),
// //       newGender: _selectedGender,
// //     );
// //     if (!success || !mounted) return;
// //     if (provider.shouldSkipAadhaarVerification) {
// //       Navigator.pushReplacementNamed(context, AppRoutes.photoCapture);
// //     } else {
// //       Navigator.pushReplacementNamed(context, AppRoutes.aadhaarVerification);
// //     }
// //   }

// //   // ── "View Certificate" → open inside app via InAppWebView ─────────────────
// //   //
// //   //  CHANGED: previously used url_launcher to open external browser.
// //   //  Now pushes CertificateWebViewScreen so the certificate renders
// //   //  inside the app without leaving it.
// //   //
// //   //  URL pattern:
// //   //    https://lc.pcmcpensioner.in/Home/view/?lc=<year_with_underscores>_<certificateId>
// //   //
// //   //  Example with financialYear="2026-2027" and certificateId=12615:
// //   //    https://lc.pcmcpensioner.in/Home/view/?lc=2026_2027_12615
// //   void _viewCertificate() {
// //     final provider = context.read<KycProvider>();
// //     final url = _buildCertUrl(provider.financialYear, provider.certificateId);

// //     if (url.isEmpty) {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         const SnackBar(
// //           content: Text('Certificate details not available. Please try again.'),
// //           backgroundColor: Colors.red,
// //         ),
// //       );
// //       return;
// //     }

// //     // Push the in-app WebView screen — no async/await needed,
// //     // no _launchingUrl state required.
// //     Navigator.push(
// //       context,
// //       MaterialPageRoute(
// //         builder: (_) => CertificateWebViewScreen(url: url),
// //       ),
// //     );
// //   }

// //   // ─────────────────────────────────────────────────────────────────────────
// //   // Build
// //   // ─────────────────────────────────────────────────────────────────────────
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor: _DS.pageBg,
// //       appBar: AppBar(
// //         backgroundColor: _DS.headerBg,
// //         elevation: 0,
// //         centerTitle: true,
// //         leading: IconButton(
// //           icon: const Icon(Icons.arrow_back, color: _DS.headerText),
// //           onPressed: () => Navigator.maybePop(context),
// //         ),
// //         title: const Text(
// //           'Pensioner Details [Step-2]',
// //           style: TextStyle(
// //             color: _DS.headerText,
// //             fontSize: 18,
// //             fontWeight: FontWeight.w700,
// //           ),
// //         ),
// //       ),
// //       body: Consumer<KycProvider>(
// //         builder: (_, provider, __) {
// //           final isReadOnly =
// //               provider.isKycCompleted || provider.isReturningPensioner;

// //           return SingleChildScrollView(
// //             padding: const EdgeInsets.fromLTRB(14, 18, 14, 100),
// //             child: Column(
// //               crossAxisAlignment: CrossAxisAlignment.stretch,
// //               children: [
// //                 // ── Details card ──────────────────────────────────────────
// //                 if (isReadOnly)
// //                   _buildReadOnlyCard(provider)
// //                 else
// //                   _buildEditableForm(provider),

// //                 const SizedBox(height: 14),

// //                 // ── Verification Status card ──────────────────────────────
// //                 _buildVerificationStatusCard(provider),

// //                 const SizedBox(height: 18),

// //                 // ── CTA Button ────────────────────────────────────────────
// //                 _buildCtaButton(provider),

// //                 // ── Error ─────────────────────────────────────────────────
// //                 if (provider.error != null) ...[
// //                   const SizedBox(height: 14),
// //                   Container(
// //                     padding: const EdgeInsets.all(12),
// //                     decoration: BoxDecoration(
// //                       color: Colors.red.withValues(alpha: 0.08),
// //                       borderRadius: BorderRadius.circular(10),
// //                     ),
// //                     child: Text(
// //                       provider.error!,
// //                       style: const TextStyle(color: Colors.red),
// //                       textAlign: TextAlign.center,
// //                     ),
// //                   ),
// //                 ],
// //               ],
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }

// //   // ── Read-only details card ────────────────────────────────────────────────
// //   Widget _buildReadOnlyCard(KycProvider provider) {
// //     return _DetailsCard(
// //       children: [
// //         _DetailRow(
// //           label: 'PPO Number(पीपीओ नंबर):',
// //           value: provider.ppoNo,
// //         ),
// //         _DetailRow(
// //           label: 'Full Name(पूर्ण नाव):',
// //           value: provider.name ?? '—',
// //         ),
// //         _DetailRow(
// //           label: 'Aadhar Number(आधार नंबर):',
// //           value: maskAadhaar(provider.aadhaarNumber),
// //           showDivider: true,
// //         ),
// //         _DetailRow(
// //           label: 'Pension Type(पेन्शन प्रकार):',
// //           value: provider.pensionType ?? '—',
// //           showDivider: true,
// //         ),
// //         _DetailRow(
// //           label: 'Address(पत्ता):',
// //           value: provider.address ?? '—',
// //           isLast: true,
// //         ),
// //       ],
// //     );
// //   }

// //   // ── Editable form card ────────────────────────────────────────────────────
// //   Widget _buildEditableForm(KycProvider provider) {
// //     return _DetailsCard(
// //       children: [
// //         _DetailRow(label: 'PPO Number(पीपीओ नंबर):', value: provider.ppoNo),
// //         _DetailRow(label: 'Full Name(पूर्ण नाव):', value: provider.name ?? '—'),
// //         Padding(
// //           padding: const EdgeInsets.symmetric(vertical: 8),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               const Text(
// //                 'Aadhar Number(आधार नंबर):',
// //                 style: TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 4),
// //               TextField(
// //                 controller: _aadhaarController,
// //                 keyboardType: TextInputType.number,
// //                 maxLength: 12,
// //                 decoration: const InputDecoration(counterText: ''),
// //               ),
// //             ],
// //           ),
// //         ),
// //         Padding(
// //           padding: const EdgeInsets.symmetric(vertical: 8),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               const Text(
// //                 'Gender:',
// //                 style: TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 4),
// //               DropdownButtonFormField<String>(
// //                 value: _selectedGender,
// //                 decoration: const InputDecoration(),
// //                 items: const [
// //                   DropdownMenuItem(value: 'Male', child: Text('Male')),
// //                   DropdownMenuItem(value: 'Female', child: Text('Female')),
// //                   DropdownMenuItem(value: 'Other', child: Text('Other')),
// //                 ],
// //                 onChanged: (val) => setState(() => _selectedGender = val),
// //               ),
// //             ],
// //           ),
// //         ),
// //         Padding(
// //           padding: const EdgeInsets.only(top: 8, bottom: 4),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               const Text(
// //                 'Address(पत्ता):',
// //                 style: TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 4),
// //               TextField(
// //                 controller: _addressController,
// //                 maxLines: 3,
// //                 decoration: const InputDecoration(),
// //               ),
// //             ],
// //           ),
// //         ),
// //       ],
// //     );
// //   }

// //   // ── Verification status card ──────────────────────────────────────────────
// //   Widget _buildVerificationStatusCard(KycProvider provider) {
// //     final status = provider.verificationStatus;
// //     final hasStatus = status != null && status.isNotEmpty;

// //     return Container(
// //       decoration: BoxDecoration(
// //         color: _DS.cardBg,
// //         borderRadius: BorderRadius.circular(_DS.cardRadius),
// //         border: Border.all(
// //           color: _DS.cardBorder,
// //           width: _DS.cardBorderWidth,
// //         ),
// //       ),
// //       padding: const EdgeInsets.symmetric(
// //         horizontal: _DS.cardPaddingH,
// //         vertical: _DS.cardPaddingV,
// //       ),
// //       child: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //           const Padding(
// //             padding: EdgeInsets.symmetric(vertical: 10),
// //             child: Text(
// //               'Verification Status(पडताळणी ची सद्यस्थिती):',
// //               style: TextStyle(
// //                 fontSize: _DS.labelFontSize,
// //                 color: _DS.labelColor,
// //                 fontWeight: FontWeight.w500,
// //               ),
// //             ),
// //           ),
// //           if (hasStatus) ...[
// //             _StatusBadge(status: status!),
// //             const SizedBox(height: 8),
// //           ] else
// //             const SizedBox(height: 28),
// //           const Divider(color: _DS.divider, thickness: 1, height: 1),
// //           const SizedBox(height: 4),
// //         ],
// //       ),
// //     );
// //   }

// //   // ── CTA button ────────────────────────────────────────────────────────────
// //   // Three states:
// //   //   1. approved  → "View Certificate" (green) → opens CertificateWebViewScreen
// //   //   2. pending   → "Verification In Progress" (disabled blue pill)
// //   //   3. otherwise → "Generate Your Life Certificate" (active blue pill)
// //   Widget _buildCtaButton(KycProvider provider) {
// //     final status = provider.verificationStatus?.toLowerCase();

// //     // ── 1. APPROVED → open certificate inside app ────────────────────────────
// //     if (status == 'approved') {
// //       return SizedBox(
// //         width: double.infinity,
// //         child: ElevatedButton(
// //           onPressed: _viewCertificate, // sync now — no _launchingUrl needed
// //           style: ElevatedButton.styleFrom(
// //             backgroundColor: const Color(0xFF28A745),
// //             padding: const EdgeInsets.symmetric(vertical: 16),
// //             shape: RoundedRectangleBorder(
// //               borderRadius: BorderRadius.circular(_DS.buttonRadius),
// //             ),
// //             elevation: 3,
// //             shadowColor: const Color(0xFF28A745).withValues(alpha: 0.4),
// //           ),
// //           child: const Column(
// //             mainAxisSize: MainAxisSize.min,
// //             children: [
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: [
// //                   Icon(Icons.workspace_premium, color: Colors.white, size: 18),
// //                   SizedBox(width: 8),
// //                   Text(
// //                     'View Certificate',
// //                     style: TextStyle(
// //                       fontSize: 15.5,
// //                       fontWeight: FontWeight.w700,
// //                       color: Colors.white,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //               SizedBox(height: 3),
// //               Text(
// //                 'प्रमाणपत्र पहा',
// //                 style: TextStyle(
// //                   fontSize: 13,
// //                   fontWeight: FontWeight.w500,
// //                   color: Colors.white,
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }

// //     // ── 2. PENDING ───────────────────────────────────────────────────────────
// //     if (status == 'pending') {
// //       return SizedBox(
// //         width: double.infinity,
// //         child: ElevatedButton(
// //           onPressed: null,
// //           style: ElevatedButton.styleFrom(
// //             backgroundColor: _DS.buttonBg,
// //             disabledBackgroundColor: _DS.buttonBg,
// //             disabledForegroundColor: _DS.buttonText,
// //             padding: const EdgeInsets.symmetric(vertical: 16),
// //             shape: RoundedRectangleBorder(
// //               borderRadius: BorderRadius.circular(_DS.buttonRadius),
// //             ),
// //             elevation: 2,
// //           ),
// //           child: const Column(
// //             mainAxisSize: MainAxisSize.min,
// //             children: [
// //               Text(
// //                 'Verification In Progress',
// //                 style: TextStyle(
// //                   fontSize: 15,
// //                   fontWeight: FontWeight.w700,
// //                   color: _DS.buttonText,
// //                 ),
// //               ),
// //               SizedBox(height: 3),
// //               Text(
// //                 'पडताळणी प्रगतीपथावर आहे',
// //                 style: TextStyle(
// //                   fontSize: 12.5,
// //                   fontWeight: FontWeight.w500,
// //                   color: _DS.buttonText,
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }

// //     // ── 3. NORMAL / FIRST-TIME ───────────────────────────────────────────────
// //     return SizedBox(
// //       width: double.infinity,
// //       child: ElevatedButton(
// //         onPressed: provider.isLoading ? null : _proceed,
// //         style: ElevatedButton.styleFrom(
// //           backgroundColor: _DS.buttonBg,
// //           padding: const EdgeInsets.symmetric(vertical: 16),
// //           shape: RoundedRectangleBorder(
// //             borderRadius: BorderRadius.circular(_DS.buttonRadius),
// //           ),
// //           elevation: 3,
// //           shadowColor: _DS.buttonBg.withValues(alpha: 0.4),
// //         ),
// //         child: provider.isLoading
// //             ? const SizedBox(
// //                 height: 22,
// //                 width: 22,
// //                 child: CircularProgressIndicator(
// //                   strokeWidth: 2.5,
// //                   valueColor: AlwaysStoppedAnimation(Colors.white),
// //                 ),
// //               )
// //             : Column(
// //                 mainAxisSize: MainAxisSize.min,
// //                 children: [
// //                   const Text(
// //                     'Generate Your Life Certificate',
// //                     style: TextStyle(
// //                       fontSize: 15.5,
// //                       fontWeight: FontWeight.w700,
// //                       color: _DS.buttonText,
// //                     ),
// //                   ),
// //                   const SizedBox(height: 3),
// //                   const Text(
// //                     'जीवन प्रमाणपत्र तयार करा',
// //                     style: TextStyle(
// //                       fontSize: 13,
// //                       fontWeight: FontWeight.w500,
// //                       color: _DS.buttonText,
// //                     ),
// //                   ),
// //                   const SizedBox(height: 2),
// //                   Text(
// //                     '(${provider.financialYear ?? '2026-2027'})',
// //                     style: const TextStyle(
// //                       fontSize: 13,
// //                       fontWeight: FontWeight.w500,
// //                       color: _DS.buttonText,
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //       ),
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // _DetailsCard
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _DetailsCard extends StatelessWidget {
// //   final List<Widget> children;
// //   const _DetailsCard({required this.children});

// //   @override
// //   Widget build(BuildContext context) {
// //     return Container(
// //       decoration: BoxDecoration(
// //         color: _DS.cardBg,
// //         borderRadius: BorderRadius.circular(_DS.cardRadius),
// //         border: Border.all(
// //           color: _DS.cardBorder,
// //           width: _DS.cardBorderWidth,
// //         ),
// //       ),
// //       padding: const EdgeInsets.symmetric(
// //         horizontal: _DS.cardPaddingH,
// //         vertical: _DS.cardPaddingV,
// //       ),
// //       child: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: children,
// //       ),
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // _DetailRow
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _DetailRow extends StatelessWidget {
// //   final String label;
// //   final String value;
// //   final bool showDivider;
// //   final bool isLast;

// //   const _DetailRow({
// //     required this.label,
// //     required this.value,
// //     this.showDivider = false,
// //     this.isLast = false,
// //   });

// //   @override
// //   Widget build(BuildContext context) {
// //     return Column(
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       children: [
// //         Padding(
// //           padding: EdgeInsets.only(
// //             top: _DS.rowPaddingV,
// //             bottom: isLast ? _DS.rowPaddingV : 2,
// //           ),
// //           child: Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 label,
// //                 style: const TextStyle(
// //                   fontSize: _DS.labelFontSize,
// //                   color: _DS.labelColor,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //               ),
// //               const SizedBox(height: 3),
// //               Text(
// //                 value,
// //                 style: const TextStyle(
// //                   fontSize: _DS.valueFontSize,
// //                   color: _DS.valueColor,
// //                   fontWeight: FontWeight.w700,
// //                 ),
// //               ),
// //             ],
// //           ),
// //         ),
// //         if (!isLast) const Divider(color: _DS.divider, thickness: 1, height: 1),
// //         if (showDivider) const SizedBox(height: 4),
// //       ],
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // _StatusBadge
// // // ─────────────────────────────────────────────────────────────────────────────
// // class _StatusBadge extends StatelessWidget {
// //   final String status;
// //   const _StatusBadge({required this.status});

// //   @override
// //   Widget build(BuildContext context) {
// //     final lower = status.toLowerCase();

// //     Color bg, border, text;
// //     IconData icon;
// //     String label, marathi;

// //     if (lower == 'approved') {
// //       bg = const Color(0xFFE8F9EE);
// //       border = const Color(0xFF34A853);
// //       text = const Color(0xFF1E8740);
// //       icon = Icons.check_circle_outline;
// //       label = 'Approved';
// //       marathi = 'मंजूर';
// //     } else if (lower == 'pending') {
// //       bg = const Color(0xFFEAF3FB);
// //       border = _DS.buttonBg;
// //       text = _DS.buttonBg;
// //       icon = Icons.hourglass_bottom;
// //       label = 'Verification In Progress';
// //       marathi = 'पडताळणी प्रगतीपथावर आहे';
// //     } else {
// //       bg = const Color(0xFFF5F5F5);
// //       border = const Color(0xFFBBBBBB);
// //       text = const Color(0xFF666666);
// //       icon = Icons.info_outline;
// //       label = status;
// //       marathi = '';
// //     }

// //     return Container(
// //       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
// //       decoration: BoxDecoration(
// //         color: bg,
// //         borderRadius: BorderRadius.circular(10),
// //         border: Border.all(color: border, width: 1.5),
// //       ),
// //       child: Row(
// //         mainAxisSize: MainAxisSize.min,
// //         children: [
// //           Icon(icon, color: text, size: 20),
// //           const SizedBox(width: 8),
// //           Column(
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 label,
// //                 style: TextStyle(
// //                   color: text,
// //                   fontWeight: FontWeight.w700,
// //                   fontSize: 13.5,
// //                 ),
// //               ),
// //               if (marathi.isNotEmpty)
// //                 Text(
// //                   marathi,
// //                   style: TextStyle(color: text, fontSize: 11),
// //                 ),
// //             ],
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }
