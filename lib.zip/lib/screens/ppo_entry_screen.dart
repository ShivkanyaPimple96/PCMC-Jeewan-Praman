import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/routes.dart';
import '../providers/kyc_provider.dart';

// ═══════════════════════════════════════════════════════════════════════════════
//  Design System
// ═══════════════════════════════════════════════════════════════════════════════
class _D {
  // ── Colours ────────────────────────────────────────────────────────────────
  static const appBarBlue = Color(0xFF92B7F7);
  static const pageBg = Color(0xFFEFEFEF);
  static const inputWhite = Colors.white;
  static const inputGrey = Color(0xFFE8E8E8);
  static const inputBorder = Color(0xFF92B7F7);
  static const textDark = Color(0xFF111111);
  static const textHint = Color(0xFF9E9E9E);
  static const btnGreen = Color(0xFF3D9142);
  static const btnGreenDisabled = Color(0xFFA5D6A7);
  static const resendOrange = Color(0xFFE05000);
  static const errorRed = Color(0xFFDC2626);
  static const approvedBg = Color(0xFFD4EDDA);
  static const approvedBorder = Color(0xFFC3E6CB);
  static const approvedText = Color(0xFF155724);
  static const approvedIcon = Color(0xFF28A745);
  static const pendingBg = Color(0xFFFFF3CD);
  static const pendingBorder = Color(0xFFFFE69C);
  static const pendingIcon = Color(0xFFD97706);

  // ── Normalised status constants (lowercase) ───────────────────────────────
  // Keep in sync with _DS in pensioner_details_screen.dart.
  static const String statusApproved = 'application approved';
  static const String statusPending = 'verification in progress';

  // ── Layout ─────────────────────────────────────────────────────────────────
  static const maxWidth = 480.0;
  static const hPad = 18.0;
  static const inputH = 56.0;
  static const btnRadius = 30.0;

  // ── Typography ─────────────────────────────────────────────────────────────
  static const titleEn =
      TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: textDark);
  static const titleMr =
      TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: textDark);
  static const sectionLabel =
      TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textDark);
  static const nameText =
      TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: textDark);
  static const otpLabel =
      TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: textDark);
  static const inputText =
      TextStyle(fontSize: 17, fontWeight: FontWeight.w500, color: textDark);
  static const btnLine1 =
      TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white);
  static const btnLine2 =
      TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white);
  static const resendText =
      TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: resendOrange);

  // ── InputDecoration factory ────────────────────────────────────────────────
  static InputDecoration inputDec({
    String? hint,
    bool readOnly = false,
    String? errorText,
    EdgeInsetsGeometry pad =
        const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
  }) =>
      InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: textHint, fontSize: 16),
        filled: true,
        fillColor: readOnly ? inputGrey : inputWhite,
        counterText: '',
        contentPadding: pad,
        errorText: errorText,
        errorStyle: const TextStyle(
          color: errorRed,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        border: _ob(2),
        enabledBorder: _ob(2),
        focusedBorder: _ob(2.5),
        disabledBorder: _ob(2),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: errorRed, width: 2),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: errorRed, width: 2.5),
        ),
      );

  static OutlineInputBorder _ob(double w) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: inputBorder, width: w),
      );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  Green Pill Button
// ═══════════════════════════════════════════════════════════════════════════════
class _GreenBtn extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final String line1;
  final String line2;

  const _GreenBtn({
    required this.onPressed,
    required this.line1,
    required this.line2,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 60,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: _D.btnGreen,
          disabledBackgroundColor: _D.btnGreenDisabled,
          foregroundColor: Colors.white,
          elevation: 3,
          shadowColor: Colors.black26,
          padding: EdgeInsets.zero,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(_D.btnRadius),
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 26,
                height: 26,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.5),
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(line1, style: _D.btnLine1),
                  const SizedBox(height: 1),
                  Text(line2, style: _D.btnLine2),
                ],
              ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  Screen
// ═══════════════════════════════════════════════════════════════════════════════
class PpoEntryScreen extends StatefulWidget {
  const PpoEntryScreen({super.key});

  @override
  State<PpoEntryScreen> createState() => _PpoEntryScreenState();
}

class _PpoEntryScreenState extends State<PpoEntryScreen> {
  final _ppoController = TextEditingController();
  final _mobileController = TextEditingController();
  final _otpController = TextEditingController();
  final _mobileFocus = FocusNode();

  /// 1 = PPO input | 2 = Name + Mobile + Get OTP | 3 = OTP entry
  int _phase = 1;

  bool _certPending = false;
  bool _certApproved = false;

  String? _mobileError;

  int _countdown = 0;
  Timer? _timer;

  @override
  void dispose() {
    _ppoController.dispose();
    _mobileController.dispose();
    _otpController.dispose();
    _mobileFocus.dispose();
    _timer?.cancel();
    super.dispose();
  }

  void _startCountdown() {
    _countdown = 30;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _countdown--);
      if (_countdown <= 0) t.cancel();
    });
  }

  // ── Mobile validation ──────────────────────────────────────────────────────
  bool _validateMobile() {
    final mobile = _mobileController.text.trim();
    if (mobile.isEmpty) {
      setState(() =>
          _mobileError = 'Mobile number is required / मोबाईल नंबर आवश्यक आहे');
      return false;
    }
    if (!RegExp(r'^\d{10}$').hasMatch(mobile)) {
      setState(() => _mobileError =
          'Enter a valid 10-digit mobile number / 10 अंकी मोबाईल नंबर टाका');
      return false;
    }
    setState(() => _mobileError = null);
    return true;
  }

  // ── Step 1 ────────────────────────────────────────────────────────────────
  Future<void> _checkPpo() async {
    final ppo = _ppoController.text.trim();
    if (ppo.isEmpty) return;
    final provider = context.read<KycProvider>();
    final result = await provider.checkPpo(ppo);
    if (!mounted || !result.found) return;
    _mobileController.text = provider.mobileNumber ?? '';
    if (provider.isReturningPensioner && result.currentYearCertId != null) {
      // FIX: normalise to lowercase before comparison
      final status = result.currentYearCertStatus?.toLowerCase().trim();
      if (status == _D.statusApproved) {
        provider.certificateId = result.currentYearCertId;
        provider.verificationStatus = result.currentYearCertStatus;
        provider.currentYearPhotoUrl = result.currentYearPhotoUrl;
        provider.currentYearVideoUrl = result.currentYearVideoUrl;
        setState(() {
          _certApproved = true;
          _phase = 2;
        });
        return;
      }
      if (status == _D.statusPending) {
        setState(() {
          _certPending = true;
          _phase = 2;
        });
        return;
      }
    }
    setState(() => _phase = 2);
  }

  // ── Step 2 ────────────────────────────────────────────────────────────────
  Future<void> _sendOtp() async {
    if (!_validateMobile()) return;

    final provider = context.read<KycProvider>();
    final success =
        await provider.sendOtp(mobile: _mobileController.text.trim());
    if (success && mounted) {
      _startCountdown();
      setState(() => _phase = 3);
    }
  }

  // ── Step 3 ────────────────────────────────────────────────────────────────
  // FIX: After OTP verification the API returns verificationStatus in the
  // response body. The KycProvider.verifyOtp() method must persist that value
  // (provider.verificationStatus = json['verificationStatus']) so that
  // PensionerDetailsScreen reads the correct status and renders the right
  // button. The navigation and status-update logic lives in KycProvider;
  // this screen simply navigates on success.
  Future<void> _verifyOtp() async {
    final otp = _otpController.text.trim();
    if (otp.isEmpty) return;
    final provider = context.read<KycProvider>();
    final success = await provider.verifyOtp(otp);
    if (success && mounted) {
      // provider.verificationStatus is now set from the OTP response.
      // PensionerDetailsScreen will read it and show the correct button.
      Navigator.pushReplacementNamed(context, AppRoutes.pensionerDetails);
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _D.appBarBlue,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Enter PPO Number [Step-1]',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      backgroundColor: _D.pageBg,
      body: Consumer<KycProvider>(
        builder: (_, provider, __) => ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: _D.maxWidth),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(_D.hPad, 28, _D.hPad, 80),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Enter Pensioner PPO Number',
                  textAlign: TextAlign.center,
                  style: _D.titleEn,
                ),
                const SizedBox(height: 4),
                const Text(
                  'पेन्शनर चा PPO नंबर टाका',
                  textAlign: TextAlign.center,
                  style: _D.titleMr,
                ),
                const SizedBox(height: 28),
                if (provider.error != null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _D.errorRed.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: _D.errorRed.withValues(alpha: 0.4)),
                    ),
                    child: Text(
                      provider.error!,
                      style: const TextStyle(color: _D.errorRed, fontSize: 14),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                if (_phase == 1)
                  _phase1(provider)
                else if (_phase == 2)
                  _phase2(provider)
                else if (_phase == 3)
                  _phase3(provider),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  Phase 1 – PPO input
  // ══════════════════════════════════════════════════════════════════════════
  Widget _phase1(KycProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: _D.inputH,
          child: TextField(
            controller: _ppoController,
            decoration: _D.inputDec(hint: 'Enter PPO Number'),
            style: _D.inputText,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _checkPpo(),
          ),
        ),
        const SizedBox(height: 28),
        _GreenBtn(
          onPressed: provider.isLoading ? null : _checkPpo,
          isLoading: provider.isLoading,
          line1: 'Submit PPO Number',
          line2: 'PPO नंबर टाका',
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  Phase 2 – Name + Mobile + Get OTP
  // ══════════════════════════════════════════════════════════════════════════
  Widget _phase2(KycProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: _D.inputH,
          child: TextField(
            controller: TextEditingController(text: provider.ppoNo),
            readOnly: true,
            decoration: _D.inputDec(readOnly: true),
            style: _D.inputText,
          ),
        ),
        const SizedBox(height: 20),

        if (_certApproved) ...[_approvedBanner(), const SizedBox(height: 16)],
        if (_certPending) ...[_pendingBanner(), const SizedBox(height: 16)],

        if (provider.name != null) ...[
          const Text('निवृत्ती वेतनधारका चे नाव:',
              textAlign: TextAlign.center, style: _D.sectionLabel),
          const SizedBox(height: 6),
          Text(provider.name!, textAlign: TextAlign.center, style: _D.nameText),
          const SizedBox(height: 20),
        ],

        const Text('Enter Your Mobile Number',
            textAlign: TextAlign.center, style: _D.sectionLabel),
        const SizedBox(height: 4),
        const Text(
          'तुमचा मोबाईल नंबर टाका',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Color(0xFF555555)),
        ),
        const SizedBox(height: 14),

        // ── Mobile field ──────────────────────────────────────────────────
        Stack(
          alignment: Alignment.centerRight,
          children: [
            TextField(
              controller: _mobileController,
              focusNode: _mobileFocus,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: _D.inputDec(
                errorText: _mobileError,
                pad: const EdgeInsets.fromLTRB(16, 18, 76, 18),
              ),
              style: _D.inputText,
              onChanged: (_) {
                if (_mobileError != null) {
                  setState(() => _mobileError = null);
                }
              },
            ),
            Positioned(
              top: 0,
              bottom: _mobileError != null ? 22 : 0,
              right: 12,
              child: Align(
                alignment: Alignment.centerRight,
                child: GestureDetector(
                  onTap: () {
                    _mobileFocus.requestFocus();
                    _mobileController.selection = TextSelection(
                      baseOffset: 0,
                      extentOffset: _mobileController.text.length,
                    );
                  },
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.edit, size: 15, color: Color(0xFF1565C0)),
                      SizedBox(width: 4),
                      Text('Edit',
                          style: TextStyle(
                            color: Color(0xFF1565C0),
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          )),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),

        _GreenBtn(
          onPressed: provider.isLoading ? null : _sendOtp,
          isLoading: provider.isLoading,
          line1: 'Get OTP',
          line2: 'OTP मिळवा',
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  Phase 3 – OTP entry
  // ══════════════════════════════════════════════════════════════════════════
  Widget _phase3(KycProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: _D.inputH,
          child: TextField(
            controller: TextEditingController(text: provider.ppoNo),
            readOnly: true,
            decoration: _D.inputDec(readOnly: true),
            style: _D.inputText,
          ),
        ),
        const SizedBox(height: 20),
        if (_certApproved) ...[_approvedBanner(), const SizedBox(height: 16)],
        if (_certPending) ...[_pendingBanner(), const SizedBox(height: 16)],
        if (provider.name != null) ...[
          const Text('निवृत्ती वेतनधारका चे नाव:',
              textAlign: TextAlign.center, style: _D.sectionLabel),
          const SizedBox(height: 6),
          Text(provider.name!, textAlign: TextAlign.center, style: _D.nameText),
          const SizedBox(height: 20),
        ],
        SizedBox(
          height: _D.inputH,
          child: TextField(
            controller:
                TextEditingController(text: provider.mobileNumber ?? ''),
            readOnly: true,
            decoration: _D.inputDec(readOnly: true),
            style: _D.inputText.copyWith(color: Colors.black54),
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'Enter OTP (OTP टाका):',
          textAlign: TextAlign.center,
          style: _D.otpLabel,
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: _D.inputH,
          child: TextField(
            controller: _otpController,
            keyboardType: TextInputType.number,
            maxLength: 6,
            decoration: _D.inputDec(hint: 'Enter OTP'),
            style: _D.inputText,
            onSubmitted: (_) => _verifyOtp(),
          ),
        ),
        const SizedBox(height: 24),
        _GreenBtn(
          onPressed: provider.isLoading ? null : _verifyOtp,
          isLoading: provider.isLoading,
          line1: 'Submit OTP',
          line2: 'OTP सबमिट करा',
        ),
        const SizedBox(height: 20),
        Center(
          child: _countdown > 0
              ? Text(
                  'Resend OTP in $_countdown seconds',
                  style: _D.resendText,
                )
              : GestureDetector(
                  onTap: _sendOtp,
                  child: const Text(
                    'Resend OTP / OTP पुन्हा पाठवा',
                    style: TextStyle(
                      color: Color(0xFF1565C0),
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                ),
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  Banners
  // ══════════════════════════════════════════════════════════════════════════
  Widget _approvedBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _D.approvedBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _D.approvedBorder, width: 2),
      ),
      child: const Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.check_circle, size: 18, color: _D.approvedIcon),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Your life certificate has been approved. Verify via OTP to view your certificate.',
              style: TextStyle(fontSize: 14, color: _D.approvedText),
            ),
          ),
        ]),
        SizedBox(height: 6),
        Text(
          'तुमचे जीवन प्रमाणपत्र मंजूर झाले आहे. प्रमाणपत्र पाहण्यासाठी OTP द्वारे सत्यापित करा.',
          style: TextStyle(fontSize: 12, color: _D.approvedText),
        ),
      ]),
    );
  }

  Widget _pendingBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _D.pendingBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _D.pendingBorder, width: 2),
      ),
      child: const Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.access_time, size: 18, color: _D.pendingIcon),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Your life certificate is under review. Verify via OTP to view its status.',
              style: TextStyle(fontSize: 14),
            ),
          ),
        ]),
        SizedBox(height: 6),
        Text(
          'तुमचे जीवन प्रमाणपत्र पुनरावलोकनाधीन आहे. स्थिती पाहण्यासाठी OTP द्वारे सत्यापित करा.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
        ),
      ]),
    );
  }
}

// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';

// // ═══════════════════════════════════════════════════════════════════════════════
// //  Design System – pixel-perfect match to the reference screenshot
// // ═══════════════════════════════════════════════════════════════════════════════
// class _D {
//   // ── Colours ────────────────────────────────────────────────────────────────
//   static const appBarBlue = Color(0xFF92B7F7);
//   static const pageBg = Color(0xFFEFEFEF);
//   static const inputWhite = Colors.white;
//   static const inputGrey = Color(0xFFE8E8E8);
//   static const inputBorder = Color(0xFF92B7F7);
//   static const textDark = Color(0xFF111111);
//   static const textHint = Color(0xFF9E9E9E);
//   static const btnGreen = Color(0xFF3D9142);
//   static const btnGreenDisabled = Color(0xFFA5D6A7);
//   static const resendOrange = Color(0xFFE05000);
//   static const errorRed = Color(0xFFDC2626);
//   static const approvedBg = Color(0xFFD4EDDA);
//   static const approvedBorder = Color(0xFFC3E6CB);
//   static const approvedText = Color(0xFF155724);
//   static const approvedIcon = Color(0xFF28A745);
//   static const pendingBg = Color(0xFFFFF3CD);
//   static const pendingBorder = Color(0xFFFFE69C);
//   static const pendingIcon = Color(0xFFD97706);

//   // ── Layout ─────────────────────────────────────────────────────────────────
//   static const maxWidth = 480.0;
//   static const hPad = 18.0;
//   static const inputH = 56.0;
//   static const btnRadius = 30.0;

//   // ── Typography ─────────────────────────────────────────────────────────────
//   static const titleEn =
//       TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: textDark);
//   static const titleMr =
//       TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: textDark);
//   static const sectionLabel =
//       TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textDark);
//   static const nameText =
//       TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: textDark);
//   static const otpLabel =
//       TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: textDark);
//   static const inputText =
//       TextStyle(fontSize: 17, fontWeight: FontWeight.w500, color: textDark);
//   static const btnLine1 =
//       TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white);
//   static const btnLine2 =
//       TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white);
//   static const resendText =
//       TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: resendOrange);

//   // ── InputDecoration factory ────────────────────────────────────────────────
//   static InputDecoration inputDec({
//     String? hint,
//     bool readOnly = false,
//     String? errorText, // ← NEW: supports inline error
//     EdgeInsetsGeometry pad =
//         const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
//   }) =>
//       InputDecoration(
//         hintText: hint,
//         hintStyle: const TextStyle(color: textHint, fontSize: 16),
//         filled: true,
//         fillColor: readOnly ? inputGrey : inputWhite,
//         counterText: '',
//         contentPadding: pad,
//         errorText: errorText, // ← NEW
//         errorStyle: const TextStyle(
//           color: errorRed,
//           fontSize: 13,
//           fontWeight: FontWeight.w600,
//         ),
//         border: _ob(2),
//         enabledBorder: _ob(2),
//         focusedBorder: _ob(2.5),
//         disabledBorder: _ob(2),
//         errorBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(color: errorRed, width: 2),
//         ),
//         focusedErrorBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(color: errorRed, width: 2.5),
//         ),
//       );

//   static OutlineInputBorder _ob(double w) => OutlineInputBorder(
//         borderRadius: BorderRadius.circular(10),
//         borderSide: BorderSide(color: inputBorder, width: w),
//       );
// }

// // ═══════════════════════════════════════════════════════════════════════════════
// //  Green Pill Button
// // ═══════════════════════════════════════════════════════════════════════════════
// class _GreenBtn extends StatelessWidget {
//   final VoidCallback? onPressed;
//   final bool isLoading;
//   final String line1;
//   final String line2;

//   const _GreenBtn({
//     required this.onPressed,
//     required this.line1,
//     required this.line2,
//     this.isLoading = false,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       width: double.infinity,
//       height: 60,
//       child: ElevatedButton(
//         onPressed: onPressed,
//         style: ElevatedButton.styleFrom(
//           backgroundColor: _D.btnGreen,
//           disabledBackgroundColor: _D.btnGreenDisabled,
//           foregroundColor: Colors.white,
//           elevation: 3,
//           shadowColor: Colors.black26,
//           padding: EdgeInsets.zero,
//           tapTargetSize: MaterialTapTargetSize.shrinkWrap,
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(_D.btnRadius),
//           ),
//         ),
//         child: isLoading
//             ? const SizedBox(
//                 width: 26,
//                 height: 26,
//                 child: CircularProgressIndicator(
//                     color: Colors.white, strokeWidth: 2.5),
//               )
//             : Column(
//                 mainAxisSize: MainAxisSize.min,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text(line1, style: _D.btnLine1),
//                   const SizedBox(height: 1),
//                   Text(line2, style: _D.btnLine2),
//                 ],
//               ),
//       ),
//     );
//   }
// }

// // ═══════════════════════════════════════════════════════════════════════════════
// //  Screen
// // ═══════════════════════════════════════════════════════════════════════════════
// class PpoEntryScreen extends StatefulWidget {
//   const PpoEntryScreen({super.key});

//   @override
//   State<PpoEntryScreen> createState() => _PpoEntryScreenState();
// }

// class _PpoEntryScreenState extends State<PpoEntryScreen> {
//   final _ppoController = TextEditingController();
//   final _mobileController = TextEditingController();
//   final _otpController = TextEditingController();
//   final _mobileFocus = FocusNode();

//   /// 1 = PPO input | 2 = Name + Mobile + Get OTP | 3 = OTP entry
//   int _phase = 1;

//   bool _certPending = false;
//   bool _certApproved = false;

//   // ── NEW: inline mobile validation error ───────────────────────────────────
//   String? _mobileError;

//   int _countdown = 0;
//   Timer? _timer;

//   @override
//   void dispose() {
//     _ppoController.dispose();
//     _mobileController.dispose();
//     _otpController.dispose();
//     _mobileFocus.dispose();
//     _timer?.cancel();
//     super.dispose();
//   }

//   void _startCountdown() {
//     _countdown = 30;
//     _timer?.cancel();
//     _timer = Timer.periodic(const Duration(seconds: 1), (t) {
//       setState(() => _countdown--);
//       if (_countdown <= 0) t.cancel();
//     });
//   }

//   // ── NEW: mobile validation helper ─────────────────────────────────────────
//   /// Returns true if valid, false + sets _mobileError if invalid.
//   bool _validateMobile() {
//     final mobile = _mobileController.text.trim();
//     if (mobile.isEmpty) {
//       setState(() =>
//           _mobileError = 'Mobile number is required / मोबाईल नंबर आवश्यक आहे');
//       return false;
//     }
//     if (!RegExp(r'^\d{10}$').hasMatch(mobile)) {
//       setState(() => _mobileError =
//           'Enter a valid 10-digit mobile number / 10 अंकी मोबाईल नंबर टाका');
//       return false;
//     }
//     setState(() => _mobileError = null);
//     return true;
//   }

//   // ── Step 1 ────────────────────────────────────────────────────────────────
//   Future<void> _checkPpo() async {
//     final ppo = _ppoController.text.trim();
//     if (ppo.isEmpty) return;
//     final provider = context.read<KycProvider>();
//     final result = await provider.checkPpo(ppo);
//     if (!mounted || !result.found) return;
//     _mobileController.text = provider.mobileNumber ?? '';
//     if (provider.isReturningPensioner && result.currentYearCertId != null) {
//       final status = result.currentYearCertStatus?.toLowerCase();
//       if (status == 'approved') {
//         provider.certificateId = result.currentYearCertId;
//         provider.verificationStatus = result.currentYearCertStatus;
//         provider.currentYearPhotoUrl = result.currentYearPhotoUrl;
//         provider.currentYearVideoUrl = result.currentYearVideoUrl;
//         setState(() {
//           _certApproved = true;
//           _phase = 2;
//         });
//         return;
//       }
//       if (status == 'pending') {
//         setState(() {
//           _certPending = true;
//           _phase = 2;
//         });
//         return;
//       }
//     }
//     setState(() => _phase = 2);
//   }

//   // ── Step 2 ────────────────────────────────────────────────────────────────
//   Future<void> _sendOtp() async {
//     // ── VALIDATION GATE ──────────────────────────────────────────────────
//     if (!_validateMobile()) return; // ← blocks if not exactly 10 digits

//     final provider = context.read<KycProvider>();
//     final success =
//         await provider.sendOtp(mobile: _mobileController.text.trim());
//     if (success && mounted) {
//       _startCountdown();
//       setState(() => _phase = 3);
//     }
//   }

//   // ── Step 3 ────────────────────────────────────────────────────────────────
//   Future<void> _verifyOtp() async {
//     final otp = _otpController.text.trim();
//     if (otp.isEmpty) return;
//     final provider = context.read<KycProvider>();
//     final success = await provider.verifyOtp(otp);
//     if (success && mounted) {
//       Navigator.pushReplacementNamed(context, AppRoutes.pensionerDetails);
//     }
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  BUILD
//   // ══════════════════════════════════════════════════════════════════════════
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: _D.appBarBlue,
//         elevation: 0,
//         centerTitle: true,
//         iconTheme: const IconThemeData(color: Colors.black87),
//         title: const Text(
//           'Enter PPO Number [Step-1]',
//           style: TextStyle(
//             color: Colors.black87,
//             fontSize: 18,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//       ),
//       backgroundColor: _D.pageBg,
//       body: Consumer<KycProvider>(
//         builder: (_, provider, __) => ConstrainedBox(
//           constraints: const BoxConstraints(maxWidth: _D.maxWidth),
//           child: SingleChildScrollView(
//             padding: const EdgeInsets.fromLTRB(_D.hPad, 28, _D.hPad, 80),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               children: [
//                 const Text(
//                   'Enter Pensioner PPO Number',
//                   textAlign: TextAlign.center,
//                   style: _D.titleEn,
//                 ),
//                 const SizedBox(height: 4),
//                 const Text(
//                   'पेन्शनर चा PPO नंबर टाका',
//                   textAlign: TextAlign.center,
//                   style: _D.titleMr,
//                 ),
//                 const SizedBox(height: 28),
//                 if (provider.error != null) ...[
//                   Container(
//                     padding: const EdgeInsets.all(12),
//                     decoration: BoxDecoration(
//                       color: _D.errorRed.withValues(alpha: 0.1),
//                       borderRadius: BorderRadius.circular(10),
//                       border:
//                           Border.all(color: _D.errorRed.withValues(alpha: 0.4)),
//                     ),
//                     child: Text(
//                       provider.error!,
//                       style: const TextStyle(color: _D.errorRed, fontSize: 14),
//                       textAlign: TextAlign.center,
//                     ),
//                   ),
//                   const SizedBox(height: 16),
//                 ],
//                 if (_phase == 1)
//                   _phase1(provider)
//                 else if (_phase == 2)
//                   _phase2(provider)
//                 else if (_phase == 3)
//                   _phase3(provider),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Phase 1 – PPO input
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _phase1(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: _ppoController,
//             decoration: _D.inputDec(hint: 'Enter PPO Number'),
//             style: _D.inputText,
//             textInputAction: TextInputAction.done,
//             onSubmitted: (_) => _checkPpo(),
//           ),
//         ),
//         const SizedBox(height: 28),
//         _GreenBtn(
//           onPressed: provider.isLoading ? null : _checkPpo,
//           isLoading: provider.isLoading,
//           line1: 'Submit PPO Number',
//           line2: 'PPO नंबर टाका',
//         ),
//       ],
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Phase 2 – Name + Mobile + Get OTP
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _phase2(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         // PPO read-only
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: TextEditingController(text: provider.ppoNo),
//             readOnly: true,
//             decoration: _D.inputDec(readOnly: true),
//             style: _D.inputText,
//           ),
//         ),
//         const SizedBox(height: 20),

//         if (_certApproved) ...[_approvedBanner(), const SizedBox(height: 16)],
//         if (_certPending) ...[_pendingBanner(), const SizedBox(height: 16)],

//         if (provider.name != null) ...[
//           const Text('निवृत्ती वेतनधारका चे नाव:',
//               textAlign: TextAlign.center, style: _D.sectionLabel),
//           const SizedBox(height: 6),
//           Text(provider.name!, textAlign: TextAlign.center, style: _D.nameText),
//           const SizedBox(height: 20),
//         ],

//         const Text('Enter Your Mobile Number',
//             textAlign: TextAlign.center, style: _D.sectionLabel),
//         const SizedBox(height: 4),
//         const Text(
//           'तुमचा मोबाईल नंबर टाका',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//               fontSize: 14,
//               fontWeight: FontWeight.w600,
//               color: Color(0xFF555555)),
//         ),
//         const SizedBox(height: 14),

//         // ── Mobile field with validation ─────────────────────────────────
//         // Height is NOT fixed here so the error text can expand below it.
//         Stack(
//           alignment: Alignment.centerRight,
//           children: [
//             TextField(
//               controller: _mobileController,
//               focusNode: _mobileFocus,
//               keyboardType: TextInputType.phone,
//               maxLength: 10,
//               decoration: _D.inputDec(
//                 errorText: _mobileError, // ← shows red error text
//                 pad: const EdgeInsets.fromLTRB(16, 18, 76, 18),
//               ),
//               style: _D.inputText,
//               onChanged: (_) {
//                 // Clear error as soon as the user starts correcting
//                 if (_mobileError != null) {
//                   setState(() => _mobileError = null);
//                 }
//               },
//             ),
//             // Keep the Edit button vertically centred in the 56-px input zone
//             Positioned(
//               top: 0,
//               bottom:
//                   _mobileError != null ? 22 : 0, // shift up when error shows
//               right: 12,
//               child: Align(
//                 alignment: Alignment.centerRight,
//                 child: GestureDetector(
//                   onTap: () {
//                     _mobileFocus.requestFocus();
//                     _mobileController.selection = TextSelection(
//                       baseOffset: 0,
//                       extentOffset: _mobileController.text.length,
//                     );
//                   },
//                   child: const Row(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Icon(Icons.edit, size: 15, color: Color(0xFF1565C0)),
//                       SizedBox(width: 4),
//                       Text('Edit',
//                           style: TextStyle(
//                             color: Color(0xFF1565C0),
//                             fontWeight: FontWeight.w700,
//                             fontSize: 14,
//                           )),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//         const SizedBox(height: 24),

//         _GreenBtn(
//           onPressed: provider.isLoading ? null : _sendOtp,
//           isLoading: provider.isLoading,
//           line1: 'Get OTP',
//           line2: 'OTP मिळवा',
//         ),
//       ],
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Phase 3 – OTP entry
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _phase3(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: TextEditingController(text: provider.ppoNo),
//             readOnly: true,
//             decoration: _D.inputDec(readOnly: true),
//             style: _D.inputText,
//           ),
//         ),
//         const SizedBox(height: 20),
//         if (_certApproved) ...[_approvedBanner(), const SizedBox(height: 16)],
//         if (_certPending) ...[_pendingBanner(), const SizedBox(height: 16)],
//         if (provider.name != null) ...[
//           const Text('निवृत्ती वेतनधारका चे नाव:',
//               textAlign: TextAlign.center, style: _D.sectionLabel),
//           const SizedBox(height: 6),
//           Text(provider.name!, textAlign: TextAlign.center, style: _D.nameText),
//           const SizedBox(height: 20),
//         ],
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller:
//                 TextEditingController(text: provider.mobileNumber ?? ''),
//             readOnly: true,
//             decoration: _D.inputDec(readOnly: true),
//             style: _D.inputText.copyWith(color: Colors.black54),
//           ),
//         ),
//         const SizedBox(height: 24),
//         const Text(
//           'Enter OTP (OTP टाका):',
//           textAlign: TextAlign.center,
//           style: _D.otpLabel,
//         ),
//         const SizedBox(height: 14),
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: _otpController,
//             keyboardType: TextInputType.number,
//             maxLength: 6,
//             decoration: _D.inputDec(hint: 'Enter OTP'),
//             style: _D.inputText,
//             onSubmitted: (_) => _verifyOtp(),
//           ),
//         ),
//         const SizedBox(height: 24),
//         _GreenBtn(
//           onPressed: provider.isLoading ? null : _verifyOtp,
//           isLoading: provider.isLoading,
//           line1: 'Submit OTP',
//           line2: 'OTP सबमिट करा',
//         ),
//         const SizedBox(height: 20),
//         Center(
//           child: _countdown > 0
//               ? Text(
//                   'Resend OTP in $_countdown seconds',
//                   style: _D.resendText,
//                 )
//               : GestureDetector(
//                   onTap: _sendOtp,
//                   child: const Text(
//                     'Resend OTP / OTP पुन्हा पाठवा',
//                     style: TextStyle(
//                       color: Color(0xFF1565C0),
//                       fontWeight: FontWeight.w700,
//                       fontSize: 16,
//                     ),
//                   ),
//                 ),
//         ),
//       ],
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Banners
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _approvedBanner() {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: _D.approvedBg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: _D.approvedBorder, width: 2),
//       ),
//       child: const Column(children: [
//         Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
//           Icon(Icons.check_circle, size: 18, color: _D.approvedIcon),
//           SizedBox(width: 8),
//           Expanded(
//             child: Text(
//               'Your life certificate has been approved. Verify via OTP to view your certificate.',
//               style: TextStyle(fontSize: 14, color: _D.approvedText),
//             ),
//           ),
//         ]),
//         SizedBox(height: 6),
//         Text(
//           'तुमचे जीवन प्रमाणपत्र मंजूर झाले आहे. प्रमाणपत्र पाहण्यासाठी OTP द्वारे सत्यापित करा.',
//           style: TextStyle(fontSize: 12, color: _D.approvedText),
//         ),
//       ]),
//     );
//   }

//   Widget _pendingBanner() {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: _D.pendingBg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: _D.pendingBorder, width: 2),
//       ),
//       child: const Column(children: [
//         Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
//           Icon(Icons.access_time, size: 18, color: _D.pendingIcon),
//           SizedBox(width: 8),
//           Expanded(
//             child: Text(
//               'Your life certificate is under review. Verify via OTP to view its status.',
//               style: TextStyle(fontSize: 14),
//             ),
//           ),
//         ]),
//         SizedBox(height: 6),
//         Text(
//           'तुमचे जीवन प्रमाणपत्र पुनरावलोकनाधीन आहे. स्थिती पाहण्यासाठी OTP द्वारे सत्यापित करा.',
//           style: TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
//         ),
//       ]),
//     );
//   }
// }

// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';

// // ═══════════════════════════════════════════════════════════════════════════════
// //  Design System – pixel-perfect match to the reference screenshot
// // ═══════════════════════════════════════════════════════════════════════════════
// class _D {
//   // ── Colours ────────────────────────────────────────────────────────────────
//   /// Light periwinkle AppBar  (#92B7F7)
//   static const appBarBlue = Color(0xFF92B7F7);

//   /// Very light grey page background
//   static const pageBg = Color(0xFFEFEFEF);

//   /// White fill for active/editable inputs
//   static const inputWhite = Colors.white;

//   /// Light grey fill for read-only inputs  (#E8E8E8)
//   static const inputGrey = Color(0xFFE8E8E8);

//   /// Blue border around every input field  (#92B7F7)
//   static const inputBorder = Color(0xFF92B7F7);

//   /// Dark near-black text
//   static const textDark = Color(0xFF111111);

//   /// Hint placeholder text
//   static const textHint = Color(0xFF9E9E9E);

//   /// Green button  (#3D9142)
//   static const btnGreen = Color(0xFF3D9142);
//   static const btnGreenDisabled = Color(0xFFA5D6A7);

//   /// Resend-OTP orange-red
//   static const resendOrange = Color(0xFFE05000);

//   /// Error
//   static const errorRed = Color(0xFFDC2626);

//   /// Approved banner
//   static const approvedBg = Color(0xFFD4EDDA);
//   static const approvedBorder = Color(0xFFC3E6CB);
//   static const approvedText = Color(0xFF155724);
//   static const approvedIcon = Color(0xFF28A745);

//   /// Pending banner
//   static const pendingBg = Color(0xFFFFF3CD);
//   static const pendingBorder = Color(0xFFFFE69C);
//   static const pendingIcon = Color(0xFFD97706);

//   // ── Layout ─────────────────────────────────────────────────────────────────
//   static const maxWidth = 480.0;
//   static const hPad = 18.0;
//   static const inputH = 56.0;
//   static const btnRadius = 30.0;

//   // ── Typography ─────────────────────────────────────────────────────────────
//   static const titleEn =
//       TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: textDark);
//   static const titleMr =
//       TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: textDark);
//   static const sectionLabel =
//       TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textDark);
//   static const nameText =
//       TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: textDark);
//   static const otpLabel =
//       TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: textDark);
//   static const inputText =
//       TextStyle(fontSize: 17, fontWeight: FontWeight.w500, color: textDark);
//   static const btnLine1 =
//       TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white);
//   static const btnLine2 =
//       TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white);
//   static const resendText =
//       TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: resendOrange);

//   // ── InputDecoration factory ────────────────────────────────────────────────
//   static InputDecoration inputDec({
//     String? hint,
//     bool readOnly = false,
//     EdgeInsetsGeometry pad =
//         const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
//   }) =>
//       InputDecoration(
//         hintText: hint,
//         hintStyle: const TextStyle(color: textHint, fontSize: 16),
//         filled: true,
//         fillColor: readOnly ? inputGrey : inputWhite,
//         counterText: '',
//         contentPadding: pad,
//         border: _ob(2),
//         enabledBorder: _ob(2),
//         focusedBorder: _ob(2.5),
//         disabledBorder: _ob(2),
//       );

//   static OutlineInputBorder _ob(double w) => OutlineInputBorder(
//         borderRadius: BorderRadius.circular(10),
//         borderSide: BorderSide(color: inputBorder, width: w),
//       );
// }

// // ═══════════════════════════════════════════════════════════════════════════════
// //  Green Pill Button
// // ═══════════════════════════════════════════════════════════════════════════════
// class _GreenBtn extends StatelessWidget {
//   final VoidCallback? onPressed;
//   final bool isLoading;
//   final String line1;
//   final String line2;

//   const _GreenBtn({
//     required this.onPressed,
//     required this.line1,
//     required this.line2,
//     this.isLoading = false,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       width: double.infinity,
//       height: 60,
//       child: ElevatedButton(
//         onPressed: onPressed,
//         style: ElevatedButton.styleFrom(
//           backgroundColor: _D.btnGreen,
//           disabledBackgroundColor: _D.btnGreenDisabled,
//           foregroundColor: Colors.white,
//           elevation: 3,
//           shadowColor: Colors.black26,
//           // ── Zero out the default internal vertical padding so the
//           //    two-line bilingual text never overflows the fixed height.
//           padding: EdgeInsets.zero,
//           tapTargetSize: MaterialTapTargetSize.shrinkWrap,
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(_D.btnRadius),
//           ),
//         ),
//         child: isLoading
//             ? const SizedBox(
//                 width: 26,
//                 height: 26,
//                 child: CircularProgressIndicator(
//                     color: Colors.white, strokeWidth: 2.5),
//               )
//             : Column(
//                 mainAxisSize: MainAxisSize.min,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text(line1, style: _D.btnLine1),
//                   const SizedBox(height: 1),
//                   Text(line2, style: _D.btnLine2),
//                 ],
//               ),
//       ),
//     );
//   }
// }

// // ═══════════════════════════════════════════════════════════════════════════════
// //  Screen
// // ═══════════════════════════════════════════════════════════════════════════════
// class PpoEntryScreen extends StatefulWidget {
//   const PpoEntryScreen({super.key});

//   @override
//   State<PpoEntryScreen> createState() => _PpoEntryScreenState();
// }

// class _PpoEntryScreenState extends State<PpoEntryScreen> {
//   final _ppoController = TextEditingController();
//   final _mobileController = TextEditingController();
//   final _otpController = TextEditingController();
//   final _mobileFocus = FocusNode();

//   /// 1 = PPO input | 2 = Name + Mobile + Get OTP | 3 = OTP entry
//   int _phase = 1;

//   bool _certPending = false;
//   bool _certApproved = false;

//   int _countdown = 0;
//   Timer? _timer;

//   @override
//   void dispose() {
//     _ppoController.dispose();
//     _mobileController.dispose();
//     _otpController.dispose();
//     _mobileFocus.dispose();
//     _timer?.cancel();
//     super.dispose();
//   }

//   void _startCountdown() {
//     _countdown = 30;
//     _timer?.cancel();
//     _timer = Timer.periodic(const Duration(seconds: 1), (t) {
//       setState(() => _countdown--);
//       if (_countdown <= 0) t.cancel();
//     });
//   }

//   // ── Step 1 ────────────────────────────────────────────────────────────────
//   Future<void> _checkPpo() async {
//     final ppo = _ppoController.text.trim();
//     if (ppo.isEmpty) return;
//     final provider = context.read<KycProvider>();
//     final result = await provider.checkPpo(ppo);
//     if (!mounted || !result.found) return;
//     _mobileController.text = provider.mobileNumber ?? '';
//     if (provider.isReturningPensioner && result.currentYearCertId != null) {
//       final status = result.currentYearCertStatus?.toLowerCase();
//       if (status == 'approved') {
//         provider.certificateId = result.currentYearCertId;
//         provider.verificationStatus = result.currentYearCertStatus;
//         provider.currentYearPhotoUrl = result.currentYearPhotoUrl;
//         provider.currentYearVideoUrl = result.currentYearVideoUrl;
//         setState(() {
//           _certApproved = true;
//           _phase = 2;
//         });
//         return;
//       }
//       if (status == 'pending') {
//         setState(() {
//           _certPending = true;
//           _phase = 2;
//         });
//         return;
//       }
//     }
//     setState(() => _phase = 2);
//   }

//   // ── Step 2 ────────────────────────────────────────────────────────────────
//   Future<void> _sendOtp() async {
//     final provider = context.read<KycProvider>();
//     final success = await provider.sendOtp(mobile: _mobileController.text);
//     if (success && mounted) {
//       _startCountdown();
//       setState(() => _phase = 3);
//     }
//   }

//   // ── Step 3 ────────────────────────────────────────────────────────────────
//   Future<void> _verifyOtp() async {
//     final otp = _otpController.text.trim();
//     if (otp.isEmpty) return;
//     final provider = context.read<KycProvider>();
//     final success = await provider.verifyOtp(otp);
//     if (success && mounted) {
//       Navigator.pushReplacementNamed(context, AppRoutes.pensionerDetails);
//     }
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  BUILD
//   // ══════════════════════════════════════════════════════════════════════════
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: _D.appBarBlue,
//         elevation: 0,
//         centerTitle: true,
//         iconTheme: const IconThemeData(color: Colors.black87),
//         title: const Text(
//           'Enter PPO Number [Step-1]',
//           style: TextStyle(
//             color: Colors.black87,
//             fontSize: 18,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//       ),
//       backgroundColor: _D.pageBg,
//       body: Consumer<KycProvider>(
//         builder: (_, provider, __) => Center(
//           child: ConstrainedBox(
//             constraints: const BoxConstraints(maxWidth: _D.maxWidth),
//             child: SingleChildScrollView(
//               padding: const EdgeInsets.fromLTRB(_D.hPad, 28, _D.hPad, 80),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.stretch,
//                 children: [
//                   // ── Bilingual title (matches screenshot) ──
//                   const Text(
//                     'Enter Pensioner PPO Number',
//                     textAlign: TextAlign.center,
//                     style: _D.titleEn,
//                   ),
//                   const SizedBox(height: 4),
//                   const Text(
//                     'पेन्शनर चा PPO नंबर टाका',
//                     textAlign: TextAlign.center,
//                     style: _D.titleMr,
//                   ),
//                   const SizedBox(height: 28),

//                   // ── Error banner ──
//                   if (provider.error != null) ...[
//                     Container(
//                       padding: const EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: _D.errorRed.withValues(alpha: 0.1),
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(
//                             color: _D.errorRed.withValues(alpha: 0.4)),
//                       ),
//                       child: Text(
//                         provider.error!,
//                         style:
//                             const TextStyle(color: _D.errorRed, fontSize: 14),
//                         textAlign: TextAlign.center,
//                       ),
//                     ),
//                     const SizedBox(height: 16),
//                   ],

//                   if (_phase == 1)
//                     _phase1(provider)
//                   else if (_phase == 2)
//                     _phase2(provider)
//                   else if (_phase == 3)
//                     _phase3(provider),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Phase 1 – PPO input
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _phase1(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: _ppoController,
//             // keyboardType: TextInputType.number,
//             decoration: _D.inputDec(hint: 'Enter PPO Number'),
//             style: _D.inputText,
//             textInputAction: TextInputAction.done,
//             onSubmitted: (_) => _checkPpo(),
//           ),
//         ),
//         const SizedBox(height: 28),
//         _GreenBtn(
//           onPressed: provider.isLoading ? null : _checkPpo,
//           isLoading: provider.isLoading,
//           line1: 'Submit PPO Number',
//           line2: 'PPO नंबर टाका',
//         ),
//       ],
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Phase 2 – Name + Mobile + Get OTP
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _phase2(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         // PPO read-only
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: TextEditingController(text: provider.ppoNo),
//             readOnly: true,
//             decoration: _D.inputDec(readOnly: true),
//             style: _D.inputText,
//           ),
//         ),
//         const SizedBox(height: 20),

//         if (_certApproved) ...[_approvedBanner(), const SizedBox(height: 16)],
//         if (_certPending) ...[_pendingBanner(), const SizedBox(height: 16)],

//         // Name
//         if (provider.name != null) ...[
//           const Text('निवृत्ती वेतनधारका चे नाव:',
//               textAlign: TextAlign.center, style: _D.sectionLabel),
//           const SizedBox(height: 6),
//           Text(provider.name!, textAlign: TextAlign.center, style: _D.nameText),
//           const SizedBox(height: 20),
//         ],

//         // Mobile label
//         const Text('Enter Your Mobile Number',
//             textAlign: TextAlign.center, style: _D.sectionLabel),
//         const SizedBox(height: 4),
//         const Text(
//           'तुमचा मोबाईल नंबर टाका',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//               fontSize: 14,
//               fontWeight: FontWeight.w600,
//               color: Color(0xFF555555)),
//         ),
//         const SizedBox(height: 14),

//         // Mobile field with Edit overlay
//         SizedBox(
//           height: _D.inputH,
//           child: Stack(
//             alignment: Alignment.centerRight,
//             children: [
//               TextField(
//                 controller: _mobileController,
//                 focusNode: _mobileFocus,
//                 keyboardType: TextInputType.phone,
//                 maxLength: 10,
//                 decoration:
//                     _D.inputDec(pad: const EdgeInsets.fromLTRB(16, 18, 76, 18)),
//                 style: _D.inputText,
//               ),
//               Positioned(
//                 right: 12,
//                 child: GestureDetector(
//                   onTap: () {
//                     _mobileFocus.requestFocus();
//                     _mobileController.selection = TextSelection(
//                       baseOffset: 0,
//                       extentOffset: _mobileController.text.length,
//                     );
//                   },
//                   child: const Row(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Icon(Icons.edit, size: 15, color: Color(0xFF1565C0)),
//                       SizedBox(width: 4),
//                       Text('Edit',
//                           style: TextStyle(
//                             color: Color(0xFF1565C0),
//                             fontWeight: FontWeight.w700,
//                             fontSize: 14,
//                           )),
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 24),

//         _GreenBtn(
//           onPressed: provider.isLoading ? null : _sendOtp,
//           isLoading: provider.isLoading,
//           line1: 'Get OTP',
//           line2: 'OTP मिळवा',
//         ),
//       ],
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Phase 3 – OTP entry  (shown in the screenshot)
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _phase3(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         // PPO read-only (grey)
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: TextEditingController(text: provider.ppoNo),
//             readOnly: true,
//             decoration: _D.inputDec(readOnly: true),
//             style: _D.inputText,
//           ),
//         ),
//         const SizedBox(height: 20),

//         if (_certApproved) ...[_approvedBanner(), const SizedBox(height: 16)],
//         if (_certPending) ...[_pendingBanner(), const SizedBox(height: 16)],

//         // Name block (matches screenshot)
//         if (provider.name != null) ...[
//           const Text('निवृत्ती वेतनधारका चे नाव:',
//               textAlign: TextAlign.center, style: _D.sectionLabel),
//           const SizedBox(height: 6),
//           Text(provider.name!, textAlign: TextAlign.center, style: _D.nameText),
//           const SizedBox(height: 20),
//         ],

//         // Mobile read-only (grey — matches the greyed field in screenshot)
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller:
//                 TextEditingController(text: provider.mobileNumber ?? ''),
//             readOnly: true,
//             decoration: _D.inputDec(readOnly: true),
//             style: _D.inputText.copyWith(color: Colors.black54),
//           ),
//         ),
//         const SizedBox(height: 24),

//         // OTP label – centred bold, bilingual
//         const Text(
//           'Enter OTP (OTP टाका):',
//           textAlign: TextAlign.center,
//           style: _D.otpLabel,
//         ),
//         const SizedBox(height: 14),

//         // OTP input (white, blue border)
//         SizedBox(
//           height: _D.inputH,
//           child: TextField(
//             controller: _otpController,
//             keyboardType: TextInputType.number,
//             maxLength: 6,
//             decoration: _D.inputDec(hint: 'Enter OTP'),
//             style: _D.inputText,
//             onSubmitted: (_) => _verifyOtp(),
//           ),
//         ),
//         const SizedBox(height: 24),

//         // Submit OTP green pill button
//         _GreenBtn(
//           onPressed: provider.isLoading ? null : _verifyOtp,
//           isLoading: provider.isLoading,
//           line1: 'Submit OTP',
//           line2: 'OTP सबमिट करा',
//         ),
//         const SizedBox(height: 20),

//         // Resend countdown / link
//         Center(
//           child: _countdown > 0
//               ? Text(
//                   'Resend OTP in $_countdown seconds',
//                   style: _D.resendText,
//                 )
//               : GestureDetector(
//                   onTap: _sendOtp,
//                   child: const Text(
//                     'Resend OTP / OTP पुन्हा पाठवा',
//                     style: TextStyle(
//                       color: Color(0xFF1565C0),
//                       fontWeight: FontWeight.w700,
//                       fontSize: 16,
//                     ),
//                   ),
//                 ),
//         ),
//       ],
//     );
//   }

//   // ══════════════════════════════════════════════════════════════════════════
//   //  Banners
//   // ══════════════════════════════════════════════════════════════════════════
//   Widget _approvedBanner() {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: _D.approvedBg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: _D.approvedBorder, width: 2),
//       ),
//       child: const Column(children: [
//         Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
//           Icon(Icons.check_circle, size: 18, color: _D.approvedIcon),
//           SizedBox(width: 8),
//           Expanded(
//             child: Text(
//               'Your life certificate has been approved. Verify via OTP to view your certificate.',
//               style: TextStyle(fontSize: 14, color: _D.approvedText),
//             ),
//           ),
//         ]),
//         SizedBox(height: 6),
//         Text(
//           'तुमचे जीवन प्रमाणपत्र मंजूर झाले आहे. प्रमाणपत्र पाहण्यासाठी OTP द्वारे सत्यापित करा.',
//           style: TextStyle(fontSize: 12, color: _D.approvedText),
//         ),
//       ]),
//     );
//   }

//   Widget _pendingBanner() {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: _D.pendingBg,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: _D.pendingBorder, width: 2),
//       ),
//       child: const Column(children: [
//         Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
//           Icon(Icons.access_time, size: 18, color: _D.pendingIcon),
//           SizedBox(width: 8),
//           Expanded(
//             child: Text(
//               'Your life certificate is under review. Verify via OTP to view its status.',
//               style: TextStyle(fontSize: 14),
//             ),
//           ),
//         ]),
//         SizedBox(height: 6),
//         Text(
//           'तुमचे जीवन प्रमाणपत्र पुनरावलोकनाधीन आहे. स्थिती पाहण्यासाठी OTP द्वारे सत्यापित करा.',
//           style: TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
//         ),
//       ]),
//     );
//   }
// }

// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../config/app_theme.dart';
// import '../config/routes.dart';
// import '../providers/kyc_provider.dart';
// import '../widgets/blue_pill_button.dart';
// import '../widgets/green_button.dart';
// import '../widgets/kyc_header.dart';

// class PpoEntryScreen extends StatefulWidget {
//   const PpoEntryScreen({super.key});

//   @override
//   State<PpoEntryScreen> createState() => _PpoEntryScreenState();
// }

// class _PpoEntryScreenState extends State<PpoEntryScreen> {
//   final _ppoController = TextEditingController();
//   final _mobileController = TextEditingController();
//   final _otpController = TextEditingController();
//   final _mobileFocus = FocusNode();

//   // _phase:
//   //   1 = PPO input
//   //   2 = Name + Mobile + Get OTP  (used for normal, pending AND approved flows)
//   //   3 = OTP input                (used for normal, pending AND approved flows)
//   int _phase = 1;

//   // True when the API returned currentYearCertStatus == "Pending".
//   bool _certPending = false;

//   // True when the API returned currentYearCertStatus == "Approved".
//   // We still run the full OTP flow; after OTP success we go to pensionerDetails
//   // which shows a "View Certificate" button.
//   bool _certApproved = false;

//   int _countdown = 0;
//   Timer? _timer;

//   @override
//   void dispose() {
//     _ppoController.dispose();
//     _mobileController.dispose();
//     _otpController.dispose();
//     _mobileFocus.dispose();
//     _timer?.cancel();
//     super.dispose();
//   }

//   void _startCountdown() {
//     _countdown = 30;
//     _timer?.cancel();
//     _timer = Timer.periodic(const Duration(seconds: 1), (t) {
//       setState(() => _countdown--);
//       if (_countdown <= 0) t.cancel();
//     });
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Step 1 → check PPO
//   // ─────────────────────────────────────────────────────────────────────────
//   Future<void> _checkPpo() async {
//     final ppo = _ppoController.text.trim();
//     if (ppo.isEmpty) return;

//     final provider = context.read<KycProvider>();
//     final result = await provider.checkPpo(ppo);

//     if (!mounted || !result.found) return;

//     // Pre-fill mobile from the server response
//     _mobileController.text = provider.mobileNumber ?? '';

//     if (provider.isReturningPensioner && result.currentYearCertId != null) {
//       final status = result.currentYearCertStatus?.toLowerCase();

//       if (status == 'approved') {
//         // ✅ FIX: Mark approved and advance to Phase 2 for OTP verification.
//         //         After OTP success we navigate to pensionerDetails which
//         //         renders a "View Certificate" button for the approved cert.
//         provider.certificateId = result.currentYearCertId;
//         provider.verificationStatus = result.currentYearCertStatus;
//         provider.currentYearPhotoUrl = result.currentYearPhotoUrl;
//         provider.currentYearVideoUrl = result.currentYearVideoUrl;
//         setState(() {
//           _certApproved = true;
//           _phase = 2;
//         });
//         return;
//       }

//       if (status == 'pending') {
//         // Mark pending and advance to Phase 2 for OTP verification.
//         setState(() {
//           _certPending = true;
//           _phase = 2;
//         });
//         return;
//       }
//     }

//     // Normal (first-time or no cert yet) → Phase 2
//     setState(() => _phase = 2);
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Step 2 → send OTP
//   // ─────────────────────────────────────────────────────────────────────────
//   Future<void> _sendOtp() async {
//     final provider = context.read<KycProvider>();
//     final success = await provider.sendOtp(mobile: _mobileController.text);
//     if (success && mounted) {
//       _startCountdown();
//       setState(() => _phase = 3);
//     }
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Step 3 → verify OTP
//   //   After OTP success, ALWAYS go to pensionerDetails.
//   //   - Approved flow: pensionerDetails will show a "View Certificate" button.
//   //   - Pending flow:  pensionerDetails will show "Verification In Progress".
//   //   - Normal flow:   pensionerDetails allows fresh KYC submission.
//   // ─────────────────────────────────────────────────────────────────────────
//   Future<void> _verifyOtp() async {
//     final otp = _otpController.text.trim();
//     if (otp.isEmpty) return;

//     final provider = context.read<KycProvider>();
//     final success = await provider.verifyOtp(otp);
//     if (success && mounted) {
//       Navigator.pushReplacementNamed(context, AppRoutes.pensionerDetails);
//     }
//   }

//   // ─────────────────────────────────────────────────────────────────────────
//   // Build
//   // ─────────────────────────────────────────────────────────────────────────
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: const KycHeader(title: 'Enter PPO Number [Step-1]'),
//       backgroundColor: AppTheme.pageBg,
//       body: Consumer<KycProvider>(
//         builder: (_, provider, __) {
//           return Center(
//             child: ConstrainedBox(
//               constraints:
//                   const BoxConstraints(maxWidth: AppTheme.maxBodyWidth),
//               child: SingleChildScrollView(
//                 padding: const EdgeInsets.fromLTRB(16, 20, 16, 80),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.stretch,
//                   children: [
//                     // Page title
//                     const Text(
//                       'Enter Pensioner PPO Number',
//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         color: AppTheme.textDark,
//                       ),
//                     ),
//                     const SizedBox(height: 4),
//                     const Text(
//                       'पेन्शनर चा PPO नंबर टाका',
//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                           fontSize: 16, color: AppTheme.textSecondary),
//                     ),
//                     const SizedBox(height: 16),

//                     // Error alert
//                     if (provider.error != null) ...[
//                       Container(
//                         padding: const EdgeInsets.all(12),
//                         decoration: BoxDecoration(
//                           color: AppTheme.red.withValues(alpha: 0.1),
//                           borderRadius: BorderRadius.circular(12),
//                           border: Border.all(
//                               color: AppTheme.red.withValues(alpha: 0.3)),
//                         ),
//                         child: Text(
//                           provider.error!,
//                           style: const TextStyle(
//                               color: AppTheme.red, fontSize: 14),
//                           textAlign: TextAlign.center,
//                         ),
//                       ),
//                       const SizedBox(height: 12),
//                     ],

//                     // ── Route to the correct phase ──────────────────────────
//                     if (_phase == 1)
//                       _buildPhase1Ppo(provider)
//                     else if (_phase == 2)
//                       _buildPhase2Mobile(provider)
//                     else if (_phase == 3)
//                       _buildPhase3Otp(provider),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }

//   // ── Phase 1: PPO input ────────────────────────────────────────────────────
//   Widget _buildPhase1Ppo(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         TextField(
//           controller: _ppoController,
//           decoration: const InputDecoration(
//             hintText: 'Enter PPO Number',
//           ),
//           style: const TextStyle(fontSize: 16),
//           textInputAction: TextInputAction.done,
//           onSubmitted: (_) => _checkPpo(),
//         ),
//         const SizedBox(height: 16),
//         GreenButton(
//           onPressed: provider.isLoading ? null : _checkPpo,
//           isLoading: provider.isLoading,
//           child: const Column(
//             children: [
//               Text('Submit PPO Number',
//                   style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
//               SizedBox(height: 2),
//               Text('PPO नंबर टाका',
//                   style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // ── Phase 2: Name + editable mobile + Get OTP ─────────────────────────────
//   // Used for normal, pending AND approved flows.
//   Widget _buildPhase2Mobile(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         // PPO readonly
//         TextField(
//           controller: TextEditingController(text: provider.ppoNo),
//           readOnly: true,
//           decoration: const InputDecoration(
//             filled: true,
//             fillColor: AppTheme.pageBg,
//           ),
//           style: const TextStyle(fontSize: 16),
//         ),
//         const SizedBox(height: 16),

//         // ✅ Show approved banner when applicable
//         if (_certApproved) ...[
//           _buildApprovedBanner(),
//           const SizedBox(height: 16),
//         ],

//         // ✅ Show pending banner when applicable
//         if (_certPending) ...[
//           _buildPendingBanner(),
//           const SizedBox(height: 16),
//         ],

//         // Pensioner name
//         if (provider.name != null) ...[
//           const Text(
//             'निवृत्ती वेतनधारका चे नाव:',
//             textAlign: TextAlign.center,
//             style: TextStyle(
//               fontSize: 14,
//               fontWeight: FontWeight.w700,
//               color: AppTheme.textDark,
//             ),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             provider.name!,
//             textAlign: TextAlign.center,
//             style: const TextStyle(
//               fontSize: 22,
//               fontWeight: FontWeight.w800,
//               color: AppTheme.textDark,
//             ),
//           ),
//           const SizedBox(height: 16),
//         ],

//         // Mobile label
//         const Text(
//           'Enter Your Mobile Number',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             fontSize: 15,
//             fontWeight: FontWeight.w700,
//             color: AppTheme.textDark,
//           ),
//         ),
//         const SizedBox(height: 4),
//         const Text(
//           'तुमचा मोबाईल नंबर टाका',
//           textAlign: TextAlign.center,
//           style: TextStyle(fontSize: 13, color: AppTheme.textSecondary),
//         ),
//         const SizedBox(height: 12),

//         // Mobile input with Edit icon
//         Stack(
//           alignment: Alignment.centerRight,
//           children: [
//             TextField(
//               controller: _mobileController,
//               focusNode: _mobileFocus,
//               keyboardType: TextInputType.phone,
//               maxLength: 10,
//               decoration: const InputDecoration(
//                 counterText: '',
//                 contentPadding: EdgeInsets.fromLTRB(16, 14, 70, 14),
//               ),
//               style: const TextStyle(fontSize: 16),
//             ),
//             Positioned(
//               right: 12,
//               child: GestureDetector(
//                 onTap: () {
//                   _mobileFocus.requestFocus();
//                   _mobileController.selection = TextSelection(
//                     baseOffset: 0,
//                     extentOffset: _mobileController.text.length,
//                   );
//                 },
//                 child: const Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Icon(Icons.edit, size: 14, color: AppTheme.primaryBlue),
//                     SizedBox(width: 4),
//                     Text(
//                       'Edit',
//                       style: TextStyle(
//                         color: AppTheme.primaryBlue,
//                         fontWeight: FontWeight.w600,
//                         fontSize: 13,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//         const SizedBox(height: 16),

//         // Get OTP button
//         BluePillButton(
//           onPressed: provider.isLoading ? null : _sendOtp,
//           isLoading: provider.isLoading,
//           child: const Column(
//             children: [
//               Text('Get OTP',
//                   style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
//               SizedBox(height: 2),
//               Text('OTP मिळवा',
//                   style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // ── Phase 3: OTP entry ────────────────────────────────────────────────────
//   // Used for normal, pending AND approved flows.
//   Widget _buildPhase3Otp(KycProvider provider) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       children: [
//         // PPO readonly
//         TextField(
//           controller: TextEditingController(text: provider.ppoNo),
//           readOnly: true,
//           decoration: const InputDecoration(
//             filled: true,
//             fillColor: AppTheme.pageBg,
//           ),
//           style: const TextStyle(fontSize: 16),
//         ),
//         const SizedBox(height: 16),

//         // ✅ Show approved banner when applicable
//         if (_certApproved) ...[
//           _buildApprovedBanner(),
//           const SizedBox(height: 16),
//         ],

//         // ✅ Show pending banner when applicable
//         if (_certPending) ...[
//           _buildPendingBanner(),
//           const SizedBox(height: 16),
//         ],

//         // Pensioner name
//         if (provider.name != null) ...[
//           const Text(
//             'निवृत्ती वेतनधारका चे नाव:',
//             textAlign: TextAlign.center,
//             style: TextStyle(
//               fontSize: 13,
//               fontWeight: FontWeight.w700,
//               color: AppTheme.textDark,
//             ),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             provider.name!,
//             textAlign: TextAlign.center,
//             style: const TextStyle(
//               fontSize: 16,
//               fontWeight: FontWeight.w800,
//               color: AppTheme.textDark,
//             ),
//           ),
//           const SizedBox(height: 16),
//         ],

//         // Mobile readonly
//         TextField(
//           controller: TextEditingController(text: provider.mobileNumber ?? ''),
//           readOnly: true,
//           decoration: const InputDecoration(
//             filled: true,
//             fillColor: AppTheme.pageBg,
//           ),
//           style: const TextStyle(fontSize: 16),
//         ),
//         const SizedBox(height: 20),

//         // OTP label
//         const Text(
//           'Enter OTP (OTP टाका):',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             fontSize: 15,
//             fontWeight: FontWeight.w700,
//             color: AppTheme.textDark,
//           ),
//         ),
//         const SizedBox(height: 12),

//         // OTP input
//         TextField(
//           controller: _otpController,
//           keyboardType: TextInputType.number,
//           maxLength: 6,
//           decoration: const InputDecoration(
//             hintText: 'Enter OTP',
//             counterText: '',
//           ),
//           style: const TextStyle(fontSize: 16),
//           onSubmitted: (_) => _verifyOtp(),
//         ),
//         const SizedBox(height: 16),

//         // Submit OTP
//         GreenButton(
//           onPressed: provider.isLoading ? null : _verifyOtp,
//           isLoading: provider.isLoading,
//           child: const Column(
//             children: [
//               Text('Submit OTP',
//                   style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
//               SizedBox(height: 2),
//               Text('OTP सबमिट करा',
//                   style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),

//         // Resend OTP countdown / link
//         Center(
//           child: _countdown > 0
//               ? Text(
//                   'Resend OTP in $_countdown seconds',
//                   style: const TextStyle(
//                     color: Color(0xFFE05000),
//                     fontWeight: FontWeight.w600,
//                     fontSize: 14,
//                   ),
//                 )
//               : GestureDetector(
//                   onTap: _sendOtp,
//                   child: const Text(
//                     'Resend OTP / OTP पुन्हा पाठवा',
//                     style: TextStyle(
//                       color: AppTheme.headerBlue,
//                       fontWeight: FontWeight.w600,
//                       fontSize: 14,
//                     ),
//                   ),
//                 ),
//         ),
//       ],
//     );
//   }

//   // ── Approved info banner (shown inline in Phase 2 & 3) ───────────────────
//   // Informs the user their certificate is approved; OTP still required to view.
//   Widget _buildApprovedBanner() {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: const Color(0xFFD4EDDA),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: const Color(0xFFC3E6CB)),
//       ),
//       child: const Column(
//         children: [
//           Row(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Icon(Icons.check_circle, size: 18, color: Color(0xFF28A745)),
//               SizedBox(width: 8),
//               Expanded(
//                 child: Text(
//                   'Your life certificate has been approved. Verify via OTP to view your certificate.',
//                   style: TextStyle(fontSize: 14, color: Color(0xFF155724)),
//                 ),
//               ),
//             ],
//           ),
//           SizedBox(height: 6),
//           Text(
//             'तुमचे जीवन प्रमाणपत्र मंजूर झाले आहे. प्रमाणपत्र पाहण्यासाठी OTP द्वारे सत्यापित करा.',
//             style: TextStyle(fontSize: 12, color: Color(0xFF155724)),
//           ),
//         ],
//       ),
//     );
//   }

//   // ── Pending info banner (shown inline in Phase 2 & 3) ───────────────────
//   Widget _buildPendingBanner() {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: const Color(0xFFFFF3CD),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: const Color(0xFFFFE69C)),
//       ),
//       child: const Column(
//         children: [
//           Row(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Icon(Icons.access_time, size: 18, color: AppTheme.pendingOrange),
//               SizedBox(width: 8),
//               Expanded(
//                 child: Text(
//                   'Your life certificate is under review. Verify via OTP to view its status.',
//                   style: TextStyle(fontSize: 14),
//                 ),
//               ),
//             ],
//           ),
//           SizedBox(height: 6),
//           Text(
//             'तुमचे जीवन प्रमाणपत्र पुनरावलोकनाधीन आहे. स्थिती पाहण्यासाठी OTP द्वारे सत्यापित करा.',
//             style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
//           ),
//         ],
//       ),
//     );
//   }
// }
